import express, { type Express, type Request, type Response, type NextFunction } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { Client as ObjectStorageClient } from "@replit/object-storage";
import { storage } from "./storage";
import { sendQuotationEmail } from "./email";
import { db } from "@db";
import { reports, reportPayments, clients, clientProjects, quotations, repairs as repairsTable } from "@shared/schema";
import { eq, desc, and, or, sql } from "drizzle-orm";
import { 
  quotationFormSchema, 
  quotationItemsSchema, 
  quotationInsertSchema, 
  quotationItemInsertSchema,
  clientSchema,
  clientProjectSchema,
  clientInsertSchema,
  clientProjectInsertSchema,
  conceptSchema,
  conceptInsertSchema,
  repairFormSchema,
  repairItemsSchema,
  repairInsertSchema,
  repairItemInsertSchema,
  reportInsertSchema,
  reportItemInsertSchema,
  reportPaymentInsertSchema,
  reportPaymentUpdateSchema,
  type RepairInsert
} from "@shared/schema";
import { z } from "zod";
import crypto from "crypto";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// Resuelve la ruta del objeto en storage a partir de la URL.
// Solo se permiten fotos de reparación bajo el prefijo public/repairs/;
// cualquier otra ruta o formato (incluidas las Base64 antiguas) devuelve null.
const REPAIR_IMAGE_PREFIX = 'public/repairs/';
function resolveRepairImagePath(url: string): string | null {
  let objectPath: string | undefined;
  const bucketId = process.env.REPLIT_BUCKET_ID || '';
  if (url.startsWith('https://storage.googleapis.com/')) {
    objectPath = url.replace('https://storage.googleapis.com/', '').split('/').slice(1).join('/');
  } else if (bucketId && url.includes(`${bucketId}/`)) {
    objectPath = url.split(`${bucketId}/`)[1];
  } else if (url.startsWith('/public/')) {
    objectPath = url.slice(1); // quitar la barra inicial
  }
  if (!objectPath) return null;
  // Normalizar y validar: sin traversal y solo dentro del prefijo de fotos de reparación
  if (objectPath.includes('..') || !objectPath.startsWith(REPAIR_IMAGE_PREFIX)) return null;
  return objectPath;
}

// ¿Alguna reparación sigue referenciando esta URL de imagen?
// (Las reparaciones duplicadas comparten las mismas URLs de foto.)
async function isRepairImageReferenced(url: string): Promise<boolean> {
  const rows = await db.select({ id: repairsTable.id })
    .from(repairsTable)
    .where(or(
      eq(repairsTable.image1, url),
      eq(repairsTable.image2, url),
      eq(repairsTable.image3, url),
    ))
    .limit(1);
  return rows.length > 0;
}

// Borra del object storage una imagen de reparación a partir de su URL.
// Devuelve true si se borró; false si la URL no es válida, sigue referenciada
// por alguna reparación, o el borrado falló.
async function deleteStoredImageByUrl(url: string): Promise<boolean> {
  const objectPath = resolveRepairImagePath(url);
  if (!objectPath) return false;

  // No borrar si otra reparación aún usa la misma foto (p. ej., duplicados)
  if (await isRepairImageReferenced(url)) {
    console.log(`Imagen aún referenciada por otra reparación, no se borra: ${url.slice(0, 100)}`);
    return false;
  }

  const client = new ObjectStorageClient({ bucketId: process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID });
  const result = await client.delete(objectPath);
  if (!result.ok) {
    console.error("Error eliminando de Object Storage:", result.error);
    return false;
  }
  return true;
}

// ==== Sesión persistente con cookie firmada (30 días) ====
const SESSION_COOKIE = "peza_session";
const SESSION_DAYS = 30;

function getSessionSecret(): string {
  // Derivado de las credenciales: si cambia la contraseña, las sesiones se invalidan
  const base = `${process.env.ADMIN_EMAIL || ""}|${process.env.ADMIN_PASSWORD || ""}|peza-session-v1`;
  return crypto.createHash("sha256").update(base).digest("hex");
}

function createSessionToken(email: string): string {
  const exp = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  const payload = Buffer.from(JSON.stringify({ email, exp })).toString("base64url");
  const sig = crypto.createHmac("sha256", getSessionSecret()).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

function verifySessionToken(token: string | undefined): { email: string } | null {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = crypto.createHmac("sha256", getSessionSecret()).update(payload).digest("base64url");
  try {
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (!data.exp || Date.now() > data.exp) return null;
    return { email: data.email };
  } catch {
    return null;
  }
}

function parseCookies(req: Request): Record<string, string> {
  const header = req.headers.cookie || "";
  const out: Record<string, string> = {};
  header.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx > -1) out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  });
  return out;
}

function setSessionCookie(req: Request, res: Response, token: string) {
  const isSecure = req.secure || req.headers["x-forwarded-proto"] === "https";
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isSecure,
    maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000,
    path: "/",
  });
}

// Middleware: exigir sesión activa (cookie firmada) para acciones destructivas
function requireAuth(req: Request, res: Response, next: NextFunction) {
  const session = verifySessionToken(parseCookies(req)[SESSION_COOKIE]);
  if (!session) {
    return res.status(401).json({ message: "Sesión requerida" });
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix
  const apiPrefix = "/api";

  // POST - Reporte de errores del cliente (mobile/desktop) para diagnóstico
  // Rate-limit simple en memoria por IP para evitar abuso/flooding.
  const clientErrorHits = new Map<string, { count: number; windowStart: number }>();
  const CLIENT_ERR_WINDOW_MS = 60_000;
  const CLIENT_ERR_MAX_PER_WINDOW = 30;
  const sanitizeField = (v: unknown, max: number): string => {
    if (v == null) return "";
    let s = typeof v === "string" ? v : String(v);
    // Quitar caracteres de control que romperían los logs
    s = s.replace(/[\u0000-\u001F\u007F]/g, " ");
    if (s.length > max) s = s.slice(0, max) + "…[truncated]";
    return s;
  };
  app.post(
    `${apiPrefix}/client-errors`,
    express.json({ limit: "64kb" }),
    async (req, res) => {
      try {
        const ip = (req.ip || req.socket?.remoteAddress || "unknown").toString();
        const now = Date.now();
        const hit = clientErrorHits.get(ip);
        if (!hit || now - hit.windowStart > CLIENT_ERR_WINDOW_MS) {
          clientErrorHits.set(ip, { count: 1, windowStart: now });
        } else {
          hit.count += 1;
          if (hit.count > CLIENT_ERR_MAX_PER_WINDOW) {
            return res.status(204).end();
          }
        }

        const body = req.body || {};
        const source = sanitizeField(body.source, 64) || "unknown";
        const message = sanitizeField(body.message, 1000);
        const stack = sanitizeField(body.stack, 4000);
        const componentStack = sanitizeField(body.componentStack, 4000);
        const url = sanitizeField(body.url, 500);
        const userAgent = sanitizeField(body.userAgent, 500);
        const viewport = sanitizeField(body.viewport, 32);
        const timestamp = sanitizeField(body.timestamp, 32);

        console.error(
          `[CLIENT ERROR] ${timestamp} | source=${source} | viewport=${viewport}\n` +
          `  url=${url}\n` +
          `  ua=${userAgent}\n` +
          `  message=${message}\n` +
          (stack ? `  stack=${stack.split("\n").slice(0, 12).join("\n         ")}\n` : "") +
          (componentStack ? `  componentStack=${componentStack.split("\n").slice(0, 12).join("\n         ")}\n` : "")
        );
        return res.status(204).end();
      } catch (err) {
        console.error("[CLIENT ERROR] Error al registrar:", err);
        return res.status(204).end();
      }
    }
  );

  // POST - Login endpoint
  app.post(`${apiPrefix}/login`, async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ message: "Email y contraseña son requeridos" });
      }

      // Credenciales de Péza Maquinaria (leídas de variables de entorno)
      const validEmail = process.env.ADMIN_EMAIL;
      const validPassword = process.env.ADMIN_PASSWORD;

      if (!validEmail || !validPassword) {
        console.error("ADMIN_EMAIL o ADMIN_PASSWORD no están configurados en las variables de entorno");
        return res.status(500).json({ message: "Error de configuración del servidor" });
      }

      if (email === validEmail && password === validPassword) {
        // Sesión persistente: cookie firmada válida por 30 días
        setSessionCookie(req, res, createSessionToken(email));
        return res.status(200).json({
          success: true,
          message: "Iniciaste sesión correctamente",
          user: { email },
        });
      }

      return res.status(401).json({ message: "Correo o contraseña incorrectos" });
    } catch (error) {
      console.error("Error en login:", error);
      return res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // GET - Verificar sesión activa (renueva la cookie: sesión "rodante")
  app.get(`${apiPrefix}/me`, (req, res) => {
    const session = verifySessionToken(parseCookies(req)[SESSION_COOKIE]);
    if (!session) {
      return res.status(401).json({ authenticated: false });
    }
    // Renovar la cookie para extender la sesión otros 30 días
    setSessionCookie(req, res, createSessionToken(session.email));
    return res.json({ authenticated: true, user: { email: session.email } });
  });

  // POST - Cerrar sesión
  app.post(`${apiPrefix}/logout`, (req, res) => {
    res.clearCookie(SESSION_COOKIE, { path: "/" });
    return res.json({ success: true });
  });

  // GET - Get the next quotation number
  app.get(`${apiPrefix}/quotations/next-number`, async (req, res) => {
    try {
      console.log("API - Obteniendo el siguiente número de cotización");
      const nextNumber = await storage.getNextQuotationNumber();
      console.log(`API - Número obtenido: ${nextNumber}`);
      return res.json({ nextNumber });
    } catch (error) {
      console.error("Error getting next quotation number:", error);
      return res.status(500).json({ message: "Error obteniendo el siguiente número de cotización" });
    }
  });
  
  // GET - Get a quotation by quotation number (with items)
  app.get(`${apiPrefix}/quotations/number/:number`, async (req, res) => {
    try {
      const quotationNumber = Number(req.params.number);
      if (isNaN(quotationNumber)) {
        return res.status(400).json({ message: "Número de cotización inválido" });
      }

      console.log(`API - Buscando cotización por número: ${quotationNumber}`);
      const quotation = await storage.getQuotationByNumber(quotationNumber);
      if (!quotation) {
        console.log(`API - Cotización #${quotationNumber} no encontrada`);
        return res.status(404).json({ message: "Cotización no encontrada" });
      }
      
      // Get quotation items
      const items = await storage.getQuotationItems(quotation.id);
      console.log(`API - Cotización #${quotationNumber} encontrada con ${items.length} conceptos`);
      
      // Return quotation with items
      return res.json({
        ...quotation,
        items
      });
    } catch (error) {
      console.error("Error getting quotation by number with items:", error);
      return res.status(500).json({ message: "Error obteniendo la cotización" });
    }
  });

  // GET - Get all quotations with pagination
  app.get(`${apiPrefix}/quotations`, async (req, res) => {
    try {
      const page = Number(req.query.page) || 1;
      const limit = Number(req.query.limit) || 500;
      
      const quotations = await storage.getQuotations(page, limit);
      return res.json(quotations);
    } catch (error) {
      console.error("Error getting quotations:", error);
      return res.status(500).json({ message: "Error obteniendo las cotizaciones" });
    }
  });

  // GET - Get a quotation by ID
  app.get(`${apiPrefix}/quotations/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cotización inválido" });
      }

      const quotation = await storage.getQuotationById(id);
      if (!quotation) {
        return res.status(404).json({ message: "Cotización no encontrada" });
      }

      return res.json(quotation);
    } catch (error) {
      console.error("Error getting quotation:", error);
      return res.status(500).json({ message: "Error obteniendo la cotización" });
    }
  });

  // POST - Create a new quotation
  app.post(`${apiPrefix}/quotations`, async (req, res) => {
    try {
      const { quotation, items } = req.body;
      
      // Obtenemos el número de cotización más reciente
      const nextQuotationNumber = await storage.getNextQuotationNumber();
      console.log(`POST /quotations - Usando número de cotización: ${nextQuotationNumber}`);
      
      // Sobreescribimos el número de cotización para asegurar que sea único
      const quotationWithUpdatedNumber = {
        ...quotation,
        quotationNumber: nextQuotationNumber
      };
      
      // Validate quotation data
      const validatedQuotation = quotationInsertSchema.parse(quotationWithUpdatedNumber);
      
      // Validate items data
      const validatedItems = z.array(quotationItemInsertSchema.omit({ quotationId: true })).parse(items);
      
      // Create quotation with items
      const newQuotation = await storage.createQuotation(validatedQuotation, validatedItems);
      
      // Registrar/actualizar el cliente a partir de la cotización
      await storage.registerClientFromQuotation(newQuotation);
      
      console.log(`Cotización creada con éxito: #${newQuotation.quotationNumber}`);
      return res.status(201).json(newQuotation);
    } catch (error) {
      console.error("Error creating quotation:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error creando la cotización", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // PUT - Update a quotation with items
  app.put(`${apiPrefix}/quotations/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cotización inválido" });
      }

      const { quotation, items } = req.body;
      
      // Primero obtenemos la cotización original para mantener el número original
      const originalQuotation = await storage.getQuotationById(id);
      if (!originalQuotation) {
        return res.status(404).json({ message: "Cotización no encontrada" });
      }
      
      // Aseguramos que el número de cotización no cambie en la actualización
      const quotationWithOriginalNumber = {
        ...quotation,
        quotationNumber: originalQuotation.quotationNumber
      };
      
      // Validate quotation data
      const validatedQuotation = quotationInsertSchema.partial().parse(quotationWithOriginalNumber);
      
      console.log(`Actualizando cotización #${originalQuotation.quotationNumber} (ID: ${id})`);
      
      // Update quotation basic info
      const updatedQuotation = await storage.updateQuotation(id, validatedQuotation);
      
      if (!updatedQuotation) {
        return res.status(404).json({ message: "Cotización no encontrada" });
      }
      
      // Handle items updates
      if (items && Array.isArray(items)) {
        // 1. Delete existing items that are not in the new list
        const existingItems = await storage.getQuotationItems(id);
        const newItemIds = items.filter(item => item.id).map(item => item.id);
        
        // Delete items that are not in the new list
        for (const existingItem of existingItems) {
          if (!newItemIds.includes(existingItem.id)) {
            await storage.deleteQuotationItem(existingItem.id);
          }
        }
        
        // 2. Update or create items
        for (const item of items) {
          if (item.id) {
            // Update existing item
            const validatedItem = quotationItemInsertSchema.omit({ quotationId: true }).partial().parse(item);
            await storage.updateQuotationItem(item.id, validatedItem);
          } else {
            // Create new item
            const validatedItem = quotationItemInsertSchema.omit({ quotationId: true }).parse(item);
            await storage.addQuotationItem(id, validatedItem);
          }
        }
      }
      
      // Get updated quotation with items
      const updatedItems = await storage.getQuotationItems(id);
      
      // Obtener la cotización completa actualizada
      const fullUpdatedQuotation = {
        ...updatedQuotation,
        items: updatedItems
      };
      
      // Actualizar los datos del cliente relacionado
      if (updatedQuotation.clientId) {
        await storage.syncClientData(updatedQuotation.clientId);
      }
      
      // Si la cotización tiene un proyecto, actualizar sus datos también
      if (updatedQuotation.projectId) {
        await storage.syncProjectData(updatedQuotation.projectId);
      }
      
      return res.json(fullUpdatedQuotation);
    } catch (error) {
      console.error("Error updating quotation:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error actualizando la cotización", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // DELETE - Delete a quotation
  app.delete(`${apiPrefix}/quotations/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cotización inválido" });
      }
      
      // Obtener la cotización antes de eliminarla para actualizar cliente y proyecto después
      const quotation = await storage.getQuotationById(id);
      if (!quotation) {
        return res.status(404).json({ message: "Cotización no encontrada" });
      }
      
      // Guardar referencias a cliente y proyecto si existen
      const clientId = quotation.clientId;
      const projectId = quotation.projectId;
      
      // Eliminar la cotización
      const success = await storage.deleteQuotation(id);
      
      if (!success) {
        return res.status(404).json({ message: "Error al eliminar la cotización" });
      }
      
      // Actualizar datos del cliente y proyecto relacionados
      if (clientId) {
        await storage.syncClientData(clientId);
      }
      
      if (projectId) {
        await storage.syncProjectData(projectId);
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting quotation:", error);
      return res.status(500).json({ message: "Error eliminando la cotización" });
    }
  });

  // POST - Add an item to a quotation
  app.post(`${apiPrefix}/quotations/:id/items`, async (req, res) => {
    try {
      const quotationId = Number(req.params.id);
      if (isNaN(quotationId)) {
        return res.status(400).json({ message: "ID de cotización inválido" });
      }

      const itemData = req.body;
      
      // Validate item data
      const validatedItem = quotationItemInsertSchema.omit({ quotationId: true }).parse(itemData);
      
      // Add item to quotation
      const newItem = await storage.addQuotationItem(quotationId, validatedItem);
      
      return res.status(201).json(newItem);
    } catch (error) {
      console.error("Error adding quotation item:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error agregando el artículo a la cotización" });
    }
  });

  // PUT - Update a quotation item
  app.put(`${apiPrefix}/quotations/items/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de artículo inválido" });
      }

      const itemData = req.body;
      
      // Validate item data
      const validatedItem = quotationItemInsertSchema.omit({ quotationId: true }).partial().parse(itemData);
      
      // Update quotation item
      const updatedItem = await storage.updateQuotationItem(id, validatedItem);
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Artículo no encontrado" });
      }
      
      // Actualizar cotización, cliente y proyecto relacionados
      if (updatedItem.quotationId) {
        const quotation = await storage.getQuotationById(updatedItem.quotationId);
        if (quotation && quotation.clientId) {
          await storage.syncClientData(quotation.clientId);
        }
        if (quotation && quotation.projectId) {
          await storage.syncProjectData(quotation.projectId);
        }
      }
      
      return res.json(updatedItem);
    } catch (error) {
      console.error("Error updating quotation item:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error actualizando el artículo de la cotización" });
    }
  });

  // DELETE - Delete a quotation item
  app.delete(`${apiPrefix}/quotations/items/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de artículo inválido" });
      }

      // Obtener el artículo antes de eliminarlo para saber a qué cotización pertenece
      const item = await storage.getQuotationItems(0).then(items => items.find(i => i.id === id));
      if (!item) {
        return res.status(404).json({ message: "Artículo no encontrado" });
      }
      
      // Guardar el ID de la cotización
      const quotationId = item.quotationId;
      
      // Eliminar el artículo
      const success = await storage.deleteQuotationItem(id);
      
      if (!success) {
        return res.status(404).json({ message: "Error al eliminar el artículo" });
      }
      
      // Actualizar cotización, cliente y proyecto relacionados
      if (quotationId) {
        const quotation = await storage.getQuotationById(quotationId);
        if (quotation && quotation.clientId) {
          await storage.syncClientData(quotation.clientId);
        }
        if (quotation && quotation.projectId) {
          await storage.syncProjectData(quotation.projectId);
        }
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting quotation item:", error);
      return res.status(500).json({ message: "Error eliminando el artículo de la cotización" });
    }
  });

  // GET - Get all items for a quotation
  app.get(`${apiPrefix}/quotations/:id/items`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cotización inválido" });
      }

      const items = await storage.getQuotationItems(id);
      return res.json(items);
    } catch (error) {
      console.error("Error getting quotation items:", error);
      return res.status(500).json({ message: "Error obteniendo los artículos de la cotización" });
    }
  });

  // POST - Enviar cotización por email
  app.post(`${apiPrefix}/quotations/:quotationNumber/send-email`, async (req, res) => {
    try {
      const quotationNumber = Number(req.params.quotationNumber);
      const { email, pdfContent } = req.body;
      
      if (isNaN(quotationNumber)) {
        return res.status(400).json({ message: "Número de cotización inválido" });
      }
      
      if (!email || !pdfContent) {
        return res.status(400).json({ message: "Email y contenido PDF son requeridos" });
      }
      
      const emailSent = await sendQuotationEmail(quotationNumber, email, pdfContent);
      
      if (emailSent) {
        return res.json({ success: true, message: "Email enviado exitosamente" });
      } else {
        return res.status(500).json({ success: false, message: "Error enviando el email" });
      }
    } catch (error) {
      console.error("Error enviando email:", error);
      return res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // ======================= Rutas para Clientes =======================

  // GET - Cuentas por cobrar agrupadas por cliente
  // Considera solo REPORTES con saldo > 0 (total - abonos), sin importar status.
  // Si paymentStatus === 'pagado', saldo se considera 0.
  // Marca vencido si el reporte más antiguo de un cliente tiene > 30 días o si algún reporte tiene status 'vencido'.
  app.get(`${apiPrefix}/accounts-receivable`, async (req, res) => {
    try {
      const OVERDUE_DAYS_THRESHOLD = 30;
      const now = Date.now();
      const DAY_MS = 1000 * 60 * 60 * 24;

      const allReports = await db.query.reports.findMany({
        with: {
          payments: { columns: { amount: true } },
          client: { columns: { id: true, name: true } }
        },
        orderBy: desc(reports.fechaReporte)
      });

      type PendingReport = {
        id: number;
        reportNumber: string;
        folioReporte: string;
        projectId: number;
        nombreObra: string;
        fechaReporte: Date;
        total: number;
        paid: number;
        balance: number;
        paymentStatus: string;
        daysSinceReport: number;
        isOverdue: boolean;
      };

      type ClientGroup = {
        clientId: number;
        clientName: string;
        reportsCount: number;
        totalBilled: number;
        totalPaid: number;
        balance: number;
        oldestReportDate: Date;
        oldestDays: number;
        hasOverdue: boolean;
        statusBreakdown: Record<string, number>;
        reports: PendingReport[];
      };

      const grouped = new Map<number, ClientGroup>();
      let totalBalanceGlobal = 0;
      let pendingReportsGlobal = 0;

      for (const r of allReports) {
        const total = parseFloat(r.total) || 0;
        const paid = (r.payments || []).reduce(
          (sum: number, p: any) => sum + (parseFloat(p.amount) || 0),
          0
        );
        const isMarkedPaid = r.paymentStatus === "pagado";
        const balance = isMarkedPaid ? 0 : Math.max(0, total - paid);

        if (balance <= 0) continue;

        const fecha = new Date(r.fechaReporte);
        const daysSinceReport = Math.floor((now - fecha.getTime()) / DAY_MS);
        const isOverdue =
          r.paymentStatus === "vencido" || daysSinceReport > OVERDUE_DAYS_THRESHOLD;

        pendingReportsGlobal += 1;
        totalBalanceGlobal += balance;

        const clientId = r.clientId;
        if (!grouped.has(clientId)) {
          grouped.set(clientId, {
            clientId,
            clientName: r.client?.name || r.clientName,
            reportsCount: 0,
            totalBilled: 0,
            totalPaid: 0,
            balance: 0,
            oldestReportDate: fecha,
            oldestDays: daysSinceReport,
            hasOverdue: false,
            statusBreakdown: {},
            reports: []
          });
        }

        const g = grouped.get(clientId)!;
        g.reportsCount += 1;
        g.totalBilled += total;
        g.totalPaid += paid;
        g.balance += balance;
        if (fecha < g.oldestReportDate) {
          g.oldestReportDate = fecha;
          g.oldestDays = daysSinceReport;
        }
        if (isOverdue) g.hasOverdue = true;
        g.statusBreakdown[r.paymentStatus] =
          (g.statusBreakdown[r.paymentStatus] || 0) + 1;
        g.reports.push({
          id: r.id,
          reportNumber: r.reportNumber,
          folioReporte: r.folioReporte,
          projectId: r.projectId,
          nombreObra: r.nombreObra,
          fechaReporte: fecha,
          total,
          paid,
          balance,
          paymentStatus: r.paymentStatus,
          daysSinceReport,
          isOverdue
        });
      }

      const clientsList = Array.from(grouped.values()).sort(
        (a, b) => b.balance - a.balance
      );

      return res.json({
        summary: {
          totalBalance: totalBalanceGlobal,
          clientsCount: clientsList.length,
          pendingReportsCount: pendingReportsGlobal,
          overdueClientsCount: clientsList.filter((c) => c.hasOverdue).length,
          overdueDaysThreshold: OVERDUE_DAYS_THRESHOLD
        },
        clients: clientsList
      });
    } catch (error) {
      console.error("Error obteniendo cuentas por cobrar:", error);
      return res.status(500).json({ error: "Error al obtener cuentas por cobrar" });
    }
  });

  // GET - Obtener todos los clientes con paginación
  // GET - Endpoint para estadísticas generales (sin paginación)
  app.get(`${apiPrefix}/stats`, async (req, res) => {
    try {
      const totalClients = await db.query.clients.findMany({
        columns: { id: true }
      });
      
      const totalProjects = await db.query.clientProjects.findMany({
        columns: { id: true }
      });
      
      const quotationsAgg = await db
        .select({
          count: sql<number>`COUNT(*)::int`,
          total: sql<string>`COALESCE(SUM(${quotations.total}), 0)::text`
        })
        .from(quotations);
      
      const reportsAgg = await db
        .select({
          count: sql<number>`COUNT(*)::int`,
          total: sql<string>`COALESCE(SUM(${reports.total}), 0)::text`
        })
        .from(reports);
      
      const stats = {
        totalClients: totalClients.length,
        totalProjects: totalProjects.length,
        totalCotizaciones: quotationsAgg[0]?.count ?? 0,
        totalCotizado: parseFloat(quotationsAgg[0]?.total ?? "0"),
        totalReportes: reportsAgg[0]?.count ?? 0,
        totalEnReportes: parseFloat(reportsAgg[0]?.total ?? "0"),
      };
      
      return res.json(stats);
    } catch (error) {
      console.error("Error obteniendo estadísticas:", error);
      return res.status(500).json({ message: "Error obteniendo las estadísticas" });
    }
  });

  app.get(`${apiPrefix}/clients`, async (req, res) => {
    try {
      const page = Number(req.query.page) || 1;
      const limit = Number(req.query.limit) || 500;
      const search = req.query.search as string | undefined;
      
      const clients = await storage.getClients(page, limit, search);
      return res.json(clients);
    } catch (error) {
      console.error("Error obteniendo clientes:", error);
      return res.status(500).json({ message: "Error obteniendo los clientes" });
    }
  });

  // GET - Obtener un cliente por ID con sus proyectos y cotizaciones (OPTIMIZADO)
  app.get(`${apiPrefix}/clients/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cliente inválido" });
      }

      // Obtener datos del cliente de forma optimizada (sin cargar items de cotizaciones)
      const client = await storage.getClientByIdOptimized(id);
      if (!client) {
        return res.status(404).json({ message: "Cliente no encontrado" });
      }

      // Obtener reportes del cliente con items y pagos en una sola query
      const clientReports = await storage.getReportsByClientIdWithDetails(id);
      
      // Procesar reportes (sin queries adicionales)
      const reportsWithItems = clientReports.map((report) => {
        const payments = report.payments || [];
        const totalPaid = payments.reduce((sum: number, payment: any) => sum + parseFloat(payment.amount), 0);
        const reportTotal = parseFloat(report.total) || 0;
        const remaining = reportTotal - totalPaid;
        
        return {
          ...report,
          paymentSummary: {
            totalPaid,
            remaining,
            reportTotal
          }
        };
      });
      
      const totalReportAmount = clientReports.reduce((sum, report) => {
        return sum + (parseFloat(report.total) || 0);
      }, 0);

      // Calcular total pagado y pendiente considerando paymentStatus (sincronizado con PDF)
      let totalPaidAmount = 0;
      let totalPendingAmount = 0;
      
      reportsWithItems.forEach((report) => {
        const reportTotal = parseFloat(report.total) || 0;
        
        // Si está marcado como "pagado" manualmente, considerar como 100% pagado
        if (report.paymentStatus === 'pagado') {
          totalPaidAmount += reportTotal;
        } else {
          // Si no, usar los abonos reales
          const realPaid = report.paymentSummary?.totalPaid || 0;
          totalPaidAmount += realPaid;
          totalPendingAmount += Math.max(0, reportTotal - realPaid);
        }
      });

      // Obtener todas las cotizaciones del cliente sin límite
      const clientQuotations = await db.query.quotations.findMany({
        where: eq(quotations.clientId, id),
        orderBy: desc(quotations.quotationNumber)
      });

      // Agregar información adicional al cliente
      const clientWithReportData = {
        ...client,
        totalReports: clientReports.length,
        totalReportAmount: totalReportAmount.toFixed(2),
        totalPaidAmount: totalPaidAmount.toFixed(2),
        totalPendingAmount: totalPendingAmount.toFixed(2),
        reports: reportsWithItems,
        quotations: clientQuotations
      };
      
      return res.json(clientWithReportData);
    } catch (error) {
      console.error("Error obteniendo cliente:", error);
      return res.status(500).json({ message: "Error obteniendo el cliente" });
    }
  });
  
  // POST - Crear un nuevo cliente
  app.post(`${apiPrefix}/clients`, async (req, res) => {
    try {
      const clientData = req.body;
      
      // Normalizar email: cadena vacía → null para respetar la restricción UNIQUE
      if (clientData.email === "" || clientData.email === undefined) {
        clientData.email = null;
      }
      
      // Validar datos del cliente
      const validatedClient = clientInsertSchema.parse(clientData);
      
      // Verificar duplicado de email solo si se proporcionó uno
      if (validatedClient.email) {
        const existingClient = await storage.getClientByEmail(validatedClient.email);
        if (existingClient) {
          return res.status(400).json({ message: "Ya existe un cliente con ese correo electrónico" });
        }
      }
      
      // Crear cliente
      const newClient = await storage.createClient(validatedClient);
      
      return res.status(201).json(newClient);
    } catch (error) {
      console.error("Error creando cliente:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error creando el cliente" });
    }
  });
  
  // PUT - Actualizar un cliente
  app.put(`${apiPrefix}/clients/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cliente inválido" });
      }

      const clientData = req.body;
      
      // Validar datos del cliente
      const validatedClient = clientInsertSchema.partial().parse(clientData);
      
      // Si se está actualizando el email, verificar que no exista otro cliente con ese email
      if (validatedClient.email) {
        const existingClient = await storage.getClientByEmail(validatedClient.email);
        if (existingClient && existingClient.id !== id) {
          return res.status(400).json({ message: "Ya existe otro cliente con ese correo electrónico" });
        }
      }
      
      // Actualizar cliente
      const updatedClient = await storage.updateClient(id, validatedClient);
      
      if (!updatedClient) {
        return res.status(404).json({ message: "Cliente no encontrado" });
      }
      
      return res.json(updatedClient);
    } catch (error) {
      console.error("Error actualizando cliente:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error actualizando el cliente" });
    }
  });
  
  // DELETE - Eliminar un cliente
  app.delete(`${apiPrefix}/clients/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de cliente inválido" });
      }

      const success = await storage.deleteClient(id);
      
      if (!success) {
        return res.status(404).json({ message: "Cliente no encontrado" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error eliminando cliente:", error);
      return res.status(500).json({ message: "Error eliminando el cliente" });
    }
  });
  
  // ======================= Rutas para Proyectos de Clientes =======================
  
  // GET - Obtener todos los proyectos de un cliente
  app.get(`${apiPrefix}/clients/:id/projects`, async (req, res) => {
    try {
      const clientId = Number(req.params.id);
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "ID de cliente inválido" });
      }

      const projects = await storage.getClientProjects(clientId);
      return res.json(projects);
    } catch (error) {
      console.error("Error obteniendo proyectos del cliente:", error);
      return res.status(500).json({ message: "Error obteniendo los proyectos del cliente" });
    }
  });
  
  // GET - Obtener un proyecto por ID
  app.get(`${apiPrefix}/projects/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de proyecto inválido" });
      }

      const project = await storage.getClientProjectById(id);
      if (!project) {
        return res.status(404).json({ message: "Proyecto no encontrado" });
      }
      
      // Sincronizar los datos del proyecto para asegurar que los totales estén actualizados
      const syncedProject = await storage.syncProjectData(id);
      
      return res.json(syncedProject);
    } catch (error) {
      console.error("Error obteniendo proyecto:", error);
      return res.status(500).json({ message: "Error obteniendo el proyecto" });
    }
  });

  // GET - Obtener un proyecto con todas sus cotizaciones (para la página de detalles)
  app.get(`${apiPrefix}/projects/:id/detailed`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de proyecto inválido" });
      }

      const project = await storage.getProjectWithQuotations(id);
      if (!project) {
        return res.status(404).json({ message: "Proyecto no encontrado" });
      }
      
      return res.json(project);
    } catch (error) {
      console.error("Error obteniendo proyecto detallado:", error);
      return res.status(500).json({ message: "Error obteniendo el proyecto" });
    }
  });
  
  // POST - Crear un nuevo proyecto para un cliente
  app.post(`${apiPrefix}/clients/:id/projects`, async (req, res) => {
    try {
      const clientId = Number(req.params.id);
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "ID de cliente inválido" });
      }

      const projectData = req.body;
      
      // Validar datos del proyecto
      const validatedProject = clientProjectSchema.parse({
        ...projectData,
        clientId
      });
      
      // Crear proyecto
      const newProject = await storage.createClientProject({
        name: validatedProject.name,
        clientId: validatedProject.clientId
      });
      
      return res.status(201).json(newProject);
    } catch (error) {
      console.error("Error creando proyecto:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error creando el proyecto" });
    }
  });
  
  // PUT - Actualizar un proyecto
  app.put(`${apiPrefix}/projects/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de proyecto inválido" });
      }

      const projectData = req.body;
      
      // Validar datos del proyecto
      const validatedProject = clientProjectSchema.partial().parse(projectData);
      
      // Actualizar proyecto
      const updatedProject = await storage.updateClientProject(id, validatedProject);
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Proyecto no encontrado" });
      }
      
      return res.json(updatedProject);
    } catch (error) {
      console.error("Error actualizando proyecto:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error actualizando el proyecto" });
    }
  });
  
  // DELETE - Eliminar un proyecto
  app.delete(`${apiPrefix}/projects/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de proyecto inválido" });
      }

      const success = await storage.deleteClientProject(id);
      
      if (!success) {
        return res.status(404).json({ message: "Proyecto no encontrado" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error eliminando proyecto:", error);
      return res.status(500).json({ message: "Error eliminando el proyecto" });
    }
  });
  
  // POST - Registrar un cliente a partir de una cotización existente
  app.post(`${apiPrefix}/quotations/:id/register-client`, async (req, res) => {
    try {
      const quotationId = Number(req.params.id);
      if (isNaN(quotationId)) {
        return res.status(400).json({ message: "ID de cotización inválido" });
      }

      // Obtener la cotización
      const quotation = await storage.getQuotationById(quotationId);
      if (!quotation) {
        return res.status(404).json({ message: "Cotización no encontrada" });
      }
      
      // Registrar el cliente
      const client = await storage.registerClientFromQuotation(quotation);
      
      return res.json(client);
    } catch (error) {
      console.error("Error registrando cliente desde cotización:", error);
      return res.status(500).json({ message: "Error registrando cliente desde la cotización" });
    }
  });

  // ================ API de conceptos ================

  // GET - Obtener todos los conceptos
  app.get(`${apiPrefix}/concepts`, async (req, res) => {
    try {
      console.log("API - Request para obtener conceptos:", req.query);
      let active: boolean | undefined = undefined;
      
      // Manejar el parámetro active de forma simplificada
      if (req.query.active !== undefined) {
        // Convertir el valor a booleano
        const activeValue = req.query.active;
        if (activeValue === 'true') {
          active = true;
        } else if (activeValue === 'false') {
          active = false;
        }
      }
      
      console.log(`API - Buscando conceptos ${active !== undefined ? (active ? 'activos' : 'inactivos') : 'todos'}`);
      
      // Usar la función de almacenamiento para obtener conceptos
      const concepts = await storage.getAllConcepts(active);
      
      // Procesar conceptos para añadir categoría y limpiar descripción
      const processedConcepts = concepts.map(concept => {
        const isRepair = concept.description && concept.description.startsWith('[REPAIR]');
        return {
          ...concept,
          // Limpiamos la descripción para la UI
          description: isRepair && concept.description 
            ? concept.description.replace('[REPAIR] ', '') 
            : concept.description
        };
      });
      
      // Si se solicita filtrar por categoría, aplicamos el filtro
      const category = req.query.category as string | undefined;
      if (category) {
        console.log(`API - Filtrando conceptos por categoría: ${category}`);
        const processedConcepts = concepts.filter(concept => {
          // Para 'repair', buscamos en la descripción si contiene [REPAIR]
          if (category === 'repair') {
            return concept.description && concept.description.includes('[REPAIR]');
          } else {
            // Para 'general', no debería tener [REPAIR] en la descripción
            return !concept.description || !concept.description.includes('[REPAIR]');
          }
        });
        return res.json(processedConcepts);
      }
      
      return res.json(concepts);
    } catch (error) {
      console.error("Error getting concepts:", error);
      return res.status(500).json({ message: "Error obteniendo los conceptos" });
    }
  });

  // GET - Buscar conceptos por término
  app.get(`${apiPrefix}/concepts/search`, async (req, res) => {
    try {
      const searchTerm = req.query.term as string || '';
      const active = req.query.active !== undefined 
        ? req.query.active === 'true' 
        : true;
      
      const concepts = await storage.searchConcepts(searchTerm, active);
      return res.json(concepts);
    } catch (error) {
      console.error("Error searching concepts:", error);
      return res.status(500).json({ message: "Error buscando conceptos" });
    }
  });

  // GET - Grupos de conceptos duplicados
  app.get(`${apiPrefix}/concepts/duplicates`, async (req, res) => {
    try {
      const groups = await storage.findDuplicateConceptGroups();
      return res.json(groups);
    } catch (error) {
      console.error("Error getting duplicate concepts:", error);
      return res.status(500).json({ message: "Error obteniendo los conceptos duplicados" });
    }
  });

  // POST - Unir conceptos duplicados (conserva uno, elimina el resto)
  app.post(`${apiPrefix}/concepts/merge`, async (req, res) => {
    try {
      const { keepId, removeIds } = req.body;
      if (
        typeof keepId !== "number" ||
        !Array.isArray(removeIds) ||
        removeIds.length === 0 ||
        removeIds.some((id) => typeof id !== "number")
      ) {
        return res.status(400).json({ message: "Datos inválidos para unir conceptos" });
      }

      if (removeIds.includes(keepId)) {
        return res.status(400).json({ message: "El concepto a conservar no puede estar en la lista de eliminados" });
      }

      const keepConcept = await storage.getConceptById(keepId);
      if (!keepConcept) {
        return res.status(404).json({ message: "El concepto a conservar no existe" });
      }

      // Validar que todos los conceptos a eliminar sean duplicados reales del
      // concepto a conservar (mismo nombre normalizado y mismo catálogo)
      const keepKey = storage.normalizeConceptName(keepConcept.name || "");
      const keepCategory = storage.conceptCategory(keepConcept);
      for (const removeId of removeIds) {
        const removeConcept = await storage.getConceptById(removeId);
        if (!removeConcept) {
          return res.status(404).json({ message: `El concepto con ID ${removeId} no existe` });
        }
        if (
          storage.normalizeConceptName(removeConcept.name || "") !== keepKey ||
          storage.conceptCategory(removeConcept) !== keepCategory
        ) {
          return res.status(400).json({
            message: `El concepto "${removeConcept.name}" no es un duplicado del concepto a conservar`
          });
        }
      }

      const removedCount = await storage.mergeConcepts(keepId, removeIds);
      return res.json({ success: true, removedCount, kept: keepConcept });
    } catch (error) {
      console.error("Error merging concepts:", error);
      return res.status(500).json({ message: "Error uniendo los conceptos duplicados" });
    }
  });

  // GET - Obtener un concepto por ID
  app.get(`${apiPrefix}/concepts/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de concepto inválido" });
      }

      const concept = await storage.getConceptById(id);
      if (!concept) {
        return res.status(404).json({ message: "Concepto no encontrado" });
      }

      return res.json(concept);
    } catch (error) {
      console.error("Error getting concept:", error);
      return res.status(500).json({ message: "Error obteniendo el concepto" });
    }
  });

  // POST - Crear un nuevo concepto
  app.post(`${apiPrefix}/concepts`, async (req, res) => {
    try {
      const conceptData = req.body;
      
      // Extraer solo los campos necesarios
      const { 
        name, 
        description = "", 
        defaultUnit = "pza", 
        defaultPrice = "0", 
        active = true,
      } = conceptData;
      
      if (!name || typeof name !== "string" || !name.trim()) {
        return res.status(400).json({ message: "El nombre del concepto es obligatorio" });
      }

      // Prevención de duplicados: mismo nombre ignorando mayúsculas/acentos/espacios
      // (solo dentro del mismo catálogo: general o reparación)
      const newConceptCategory: 'repair' | 'general' =
        conceptData.category === 'repair' ||
        (typeof description === 'string' && description.trim().startsWith('[REPAIR]'))
          ? 'repair'
          : 'general';
      const existingConcept = await storage.findConceptByNormalizedName(name, undefined, newConceptCategory);
      if (existingConcept) {
        return res.status(409).json({
          message: `Ya existe un concepto con ese nombre: "${existingConcept.name}"${existingConcept.active ? "" : " (está inactivo; puedes reactivarlo en el catálogo)"}`
        });
      }
      
      let conceptDescription = description;
      
      // Si es un concepto de reparación, lo marcamos en la descripción
      if (conceptData.category === 'repair') {
        conceptDescription = `[REPAIR] ${conceptDescription}`;
      }
      
      console.log("Intentando guardar concepto simplificado con storage:", { name, description: conceptDescription, defaultUnit, defaultPrice, active });
      
      // Crear objeto para storage
      const conceptToCreate = {
        name, 
        description: conceptDescription,
        defaultUnit,
        defaultPrice,
        active
      };
      
      // Usar storage para crear el concepto
      const newConcept = await storage.createConcept(conceptToCreate);
      
      // Añadir la categoría al resultado para la UI
      const result = {
        ...newConcept,
        category: 'repair'
      };
      
      return res.status(201).json(result);
    } catch (error) {
      console.error("Error creating concept:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error creando el concepto" });
    }
  });

  // PUT - Actualizar un concepto existente
  app.put(`${apiPrefix}/concepts/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de concepto inválido" });
      }

      const conceptData = req.body;
      
      // Validar datos del concepto
      const validatedConcept = conceptInsertSchema.partial().parse(conceptData);
      
      // Prevención de duplicados al renombrar (excluyendo el propio concepto,
      // solo dentro del mismo catálogo)
      if (validatedConcept.name) {
        const currentConcept = await storage.getConceptById(id);
        const currentCategory = currentConcept ? storage.conceptCategory(currentConcept) : undefined;
        const existingConcept = await storage.findConceptByNormalizedName(validatedConcept.name, id, currentCategory);
        if (existingConcept) {
          return res.status(409).json({
            message: `Ya existe otro concepto con ese nombre: "${existingConcept.name}"`
          });
        }
      }
      
      // Actualizar concepto
      const updatedConcept = await storage.updateConcept(id, validatedConcept);
      
      if (!updatedConcept) {
        return res.status(404).json({ message: "Concepto no encontrado" });
      }
      
      return res.json(updatedConcept);
    } catch (error) {
      console.error("Error updating concept:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error actualizando el concepto" });
    }
  });

  // PATCH - Cambiar el estado de activación de un concepto
  app.patch(`${apiPrefix}/concepts/:id/toggle-status`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de concepto inválido" });
      }

      const { active } = req.body;
      if (typeof active !== 'boolean') {
        return res.status(400).json({ message: "El estado de activación debe ser un booleano" });
      }
      
      const updatedConcept = await storage.toggleConceptStatus(id, active);
      
      if (!updatedConcept) {
        return res.status(404).json({ message: "Concepto no encontrado" });
      }
      
      return res.json(updatedConcept);
    } catch (error) {
      console.error("Error toggling concept status:", error);
      return res.status(500).json({ message: "Error cambiando el estado del concepto" });
    }
  });

  // DELETE - Eliminar un concepto
  app.delete(`${apiPrefix}/concepts/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de concepto inválido" });
      }
      
      const success = await storage.deleteConcept(id);
      
      if (!success) {
        return res.status(404).json({ message: "Concepto no encontrado" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting concept:", error);
      return res.status(500).json({ message: "Error eliminando el concepto" });
    }
  });

  // API para reparaciones
  
  // GET - Next repair number
  app.get(`${apiPrefix}/repairs/next-number`, async (req, res) => {
    try {
      const nextNumber = await storage.getNextRepairNumber();
      res.status(200).json({ repairNumber: nextNumber });
    } catch (error) {
      console.error("Error al obtener el siguiente número de reparación:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // GET - All repairs with pagination and optional search
  app.get(`${apiPrefix}/repairs`, async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 500;
      const search = req.query.search as string || '';
      const includeItems = req.query.includeItems === 'true';
      
      const repairs = await storage.getRepairs(page, limit);
      
      // Filtrar por búsqueda si se proporciona
      let filteredRepairs = repairs;
      if (search) {
        const lowerSearch = search.toLowerCase();
        filteredRepairs = repairs.filter((repair: any) => 
          repair.client?.name?.toLowerCase().includes(lowerSearch) ||
          repair.equipment?.toLowerCase().includes(lowerSearch) ||
          repair.repairNumber?.toLowerCase().includes(lowerSearch) ||
          repair.serialNumber?.toLowerCase().includes(lowerSearch)
        );
      }
      
      // Solo cargar items si se solicita explícitamente (no necesario para la lista)
      if (includeItems) {
        // Una sola consulta para los items de todas las reparaciones (evita N+1)
        const allItems = await storage.getRepairItemsByRepairIds(
          filteredRepairs.map((r: any) => r.id)
        );
        const itemsByRepair = new Map<number, any[]>();
        for (const item of allItems) {
          const list = itemsByRepair.get(item.repairId) || [];
          list.push(item);
          itemsByRepair.set(item.repairId, list);
        }
        const repairsWithItems = filteredRepairs.map((repair: any) => ({
          ...repair,
          items: itemsByRepair.get(repair.id) || [],
        }));
        return res.status(200).json(repairsWithItems);
      }
      
      // Respuesta ligera sin items ni imágenes para carga rápida de la lista
      const lightRepairs = filteredRepairs.map((repair: any) => {
        const { image1, image2, image3, ...rest } = repair;
        return rest;
      });
      res.status(200).json(lightRepairs);
    } catch (error) {
      console.error("Error al obtener reparaciones:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // GET - Repairs of a specific client (for estado de cuenta)
  app.get(`${apiPrefix}/clients/:clientId/repairs`, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "ID de cliente inválido" });
      }
      const clientRepairs = await storage.getRepairsByClientId(clientId);
      res.status(200).json(clientRepairs);
    } catch (error) {
      console.error("Error al obtener reparaciones del cliente:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // GET - Repair by ID
  app.get(`${apiPrefix}/repairs/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const repair = await storage.getRepairById(id);
      if (!repair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      
      res.status(200).json(repair);
    } catch (error) {
      console.error(`Error al obtener reparación con ID ${req.params.id}:`, error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // POST - Duplicate a repair
  app.post(`${apiPrefix}/repairs/:id/duplicate`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de reparación inválido" });
      }

      console.log(`API - Duplicando reparación ID: ${id}`);
      
      // Get the original repair with items
      const originalRepair = await storage.getRepairById(id);
      if (!originalRepair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }

      const items = await storage.getRepairItems(id);
      
      // Get next repair number
      const nextRepairNumber = await storage.getNextRepairNumber();
      
      // Create duplicated repair data
      const duplicatedRepairData: RepairInsert = {
        repairNumber: nextRepairNumber,
        clientId: originalRepair.clientId,
        equipment: originalRepair.equipment,
        serialNumber: originalRepair.serialNumber,
        model: originalRepair.model,
        repairManager: originalRepair.repairManager,
        receivedDate: new Date(), // Set current date for duplicated repair
        deliveryDate: originalRepair.deliveryDate,
        departureDate: originalRepair.departureDate,
        elaborationDate: originalRepair.elaborationDate,
        deliveredBy: originalRepair.deliveredBy,
        clientReport: originalRepair.clientReport,
        equipmentObservations: originalRepair.equipmentObservations,
        image1: originalRepair.image1,
        image2: originalRepair.image2,
        image3: originalRepair.image3,
        status: "Espera de confirmación",
        subtotal: originalRepair.subtotal,
        iva: originalRepair.iva,
        total: originalRepair.total,
        includeIVA: originalRepair.includeIVA,
        repairOrder: originalRepair.repairOrder,
      };

      // Create the duplicated items
      const duplicatedItems = items.map(item => ({
        itemNumber: item.itemNumber,
        concept: item.concept,
        quantity: item.quantity,
        unit: item.unit,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal,
      }));

      const newRepair = await storage.createRepair(duplicatedRepairData, duplicatedItems);
      
      console.log(`Reparación duplicada con éxito: #${newRepair.repairNumber}`);
      return res.status(201).json(newRepair);
    } catch (error) {
      console.error("Error duplicating repair:", error);
      return res.status(500).json({ message: "Error duplicando la reparación" });
    }
  });

  // POST - Create new repair
  const validPaymentStatusesRepair = ["Pagada", "No Pagada", "Cotización"];

  app.post(`${apiPrefix}/repairs`, async (req, res) => {
    try {
      // Validar los datos de la reparación
      const formData = req.body;
      
      // Obtener los items
      const items = req.body.items || [];
      
      // Obtener el cliente si existe
      let clientId = null;
      const rawEmail = formData.clientEmail?.trim() || "";
      const clientEmail = (rawEmail === "N/A" || rawEmail === "n/a" || rawEmail === "") ? "" : rawEmail;
      
      if (formData.clientName) {
        const matchingClient = await storage.getClientByName(formData.clientName);
        
        if (matchingClient) {
          clientId = matchingClient.id;
          if (clientEmail && (!matchingClient.email || matchingClient.email === "" || matchingClient.email === "N/A")) {
            await storage.updateClient(matchingClient.id, { email: clientEmail });
          }
        } else if (clientEmail) {
          const existingByEmail = await storage.getClientByEmail(clientEmail);
          if (existingByEmail) {
            clientId = existingByEmail.id;
          } else {
            const newClient = await storage.createClient({
              name: formData.clientName.trim(),
              email: clientEmail,
              totalProjects: 0,
              totalQuotations: 0,
              totalAmount: "0",
              createdAt: new Date(),
              updatedAt: new Date(),
            });
            clientId = newClient.id;
          }
        } else {
          const newClient = await storage.createClient({
            name: formData.clientName.trim(),
            email: null,
            totalProjects: 0,
            totalQuotations: 0,
            totalAmount: "0",
            createdAt: new Date(),
            updatedAt: new Date(),
          });
          clientId = newClient.id;
        }
      }
      
      // Calcular subtotal, IVA y total
      let subtotal = 0;
      items.forEach((item: any) => {
        const quantity = typeof item.quantity === 'string' ? parseFloat(item.quantity) : item.quantity;
        const unitPrice = typeof item.unitPrice === 'string' ? parseFloat(item.unitPrice) : item.unitPrice;
        subtotal += (quantity || 0) * (unitPrice || 0);
      });
      
      const includeIVA = formData.includeIVA ?? true;
      const iva = includeIVA ? subtotal * 0.16 : 0;
      const total = subtotal + iva;
      
      // Preparar los datos para guardar en la base de datos
      const repairData = {
        repairNumber: formData.repairNumber || await storage.getNextRepairNumber(),
        repairOrder: formData.repairOrder || null,
        clientId,
        clientEmail: clientEmail || "N/A",
        equipment: formData.equipment,
        serialNumber: formData.serialNumber || null,
        model: formData.model || null,
        repairManager: formData.repairManager || null,
        receivedDate: formData.receivedDate ? new Date(formData.receivedDate) : new Date(),
        deliveredBy: formData.deliveredBy || null,
        deliveryDate: formData.deliveryDate ? new Date(formData.deliveryDate) : null,
        departureDate: formData.departureDate ? new Date(formData.departureDate) : null,
        elaborationDate: formData.elaborationDate ? new Date(formData.elaborationDate) : null,
        clientReport: formData.clientReport || null,
        equipmentObservations: formData.equipmentObservations || null,
        image1: formData.image1 || null,
        image2: formData.image2 || null,
        image3: formData.image3 || null,
        subtotal: subtotal.toFixed(2),
        iva: iva.toFixed(2),
        total: total.toFixed(2),
        includeIVA,
        status: formData.status || "Espera de confirmación",
        paymentStatus: validPaymentStatusesRepair.includes(formData.paymentStatus)
          ? formData.paymentStatus
          : "No Pagada",
        reviewReason: formData.reviewReason || null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      // Preparar los items para guardar en la base de datos
      const repairItems = items.map((item: any) => {
        const quantity = typeof item.quantity === 'string' ? parseFloat(item.quantity) : item.quantity;
        const unitPrice = typeof item.unitPrice === 'string' ? parseFloat(item.unitPrice) : item.unitPrice;
        const itemSubtotal = ((quantity || 0) * (unitPrice || 0)).toFixed(2);
        
        return {
          itemNumber: item.itemNumber,
          concept: item.concept,
          quantity: item.quantity,
          unit: item.unit,
          unitPrice: item.unitPrice,
          subtotal: itemSubtotal,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
      });
      
      // Crear la reparación y sus items
      const newRepair = await storage.createRepair(repairData, repairItems);
      
      // Recalcular y sincronizar totales desde los items guardados en la BD
      await storage.updateRepairTotals(newRepair.id);
      const finalRepair = await storage.getRepairById(newRepair.id);
      
      res.status(201).json(finalRepair);
    } catch (error) {
      console.error("Error al crear reparación:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // PATCH - Update repair
  app.patch(`${apiPrefix}/repairs/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      // Obtener la reparación actual para preservar las imágenes existentes
      const currentRepair = await storage.getRepairById(id);
      if (!currentRepair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      
      // Validar los datos de la reparación
      const formData = req.body;
      
      // Obtener los items
      const items = req.body.items || [];
      
      // Obtener el cliente - buscar por nombre primero
      let clientId = currentRepair.clientId;
      const rawEmailPatch = formData.clientEmail?.trim() || "";
      const clientEmail = (rawEmailPatch === "N/A" || rawEmailPatch === "n/a" || rawEmailPatch === "") ? "" : rawEmailPatch;
      
      if (formData.clientName) {
        // Verificar si el nombre del cliente cambió comparando con el cliente actual
        const currentClient = currentRepair.clientId ? await storage.getClientById(currentRepair.clientId) : null;
        const nameChanged = !currentClient || currentClient.name.trim().toLowerCase() !== formData.clientName.trim().toLowerCase();
        
        if (nameChanged) {
          const matchingClient = await storage.getClientByName(formData.clientName);
          
          if (matchingClient) {
            clientId = matchingClient.id;
            if (clientEmail && (!matchingClient.email || matchingClient.email === "" || matchingClient.email === "N/A")) {
              await storage.updateClient(matchingClient.id, { email: clientEmail });
            }
          } else if (clientEmail) {
            const existingByEmail = await storage.getClientByEmail(clientEmail);
            if (existingByEmail) {
              clientId = existingByEmail.id;
            } else {
              const newClient = await storage.createClient({
                name: formData.clientName.trim(),
                email: clientEmail,
                totalProjects: 0,
                totalQuotations: 0,
                totalAmount: "0",
                createdAt: new Date(),
                updatedAt: new Date(),
              });
              clientId = newClient.id;
            }
          } else {
            const newClient = await storage.createClient({
              name: formData.clientName.trim(),
              email: null,
              totalProjects: 0,
              totalQuotations: 0,
              totalAmount: "0",
              createdAt: new Date(),
              updatedAt: new Date(),
            });
            clientId = newClient.id;
          }
        } else {
          // Nombre no cambió - preservar clientId existente, solo actualizar email si se proporciona
          if (clientEmail && currentClient && (!currentClient.email || currentClient.email === "" || currentClient.email === "N/A")) {
            await storage.updateClient(currentClient.id, { email: clientEmail });
          }
        }
      }
      
      // Calcular subtotal, IVA y total
      let subtotal = 0;
      items.forEach((item: any) => {
        const quantity = typeof item.quantity === 'string' ? parseFloat(item.quantity) : item.quantity;
        const unitPrice = typeof item.unitPrice === 'string' ? parseFloat(item.unitPrice) : item.unitPrice;
        subtotal += (quantity || 0) * (unitPrice || 0);
      });
      
      const includeIVA = formData.includeIVA ?? true;
      const iva = includeIVA ? subtotal * 0.16 : 0;
      const total = subtotal + iva;
      
      // Preparar los datos para actualizar en la base de datos
      // Solo actualizar imágenes si se proporcionan nuevas, de lo contrario mantener las existentes
      const repairData: Partial<RepairInsert> = {
        repairOrder: formData.repairOrder || null,
        clientId,
        clientEmail: clientEmail || "N/A",
        equipment: formData.equipment,
        serialNumber: formData.serialNumber || null,
        model: formData.model || null,
        repairManager: formData.repairManager || null,
        receivedDate: formData.receivedDate ? new Date(formData.receivedDate) : new Date(),
        deliveredBy: formData.deliveredBy || null,
        deliveryDate: formData.deliveryDate ? new Date(formData.deliveryDate) : null,
        departureDate: formData.departureDate ? new Date(formData.departureDate) : null,
        elaborationDate: formData.elaborationDate ? new Date(formData.elaborationDate) : null,
        clientReport: formData.clientReport || null,
        equipmentObservations: formData.equipmentObservations || null,
        image1: formData.image1 !== undefined ? formData.image1 : currentRepair.image1,
        image2: formData.image2 !== undefined ? formData.image2 : currentRepair.image2,
        image3: formData.image3 !== undefined ? formData.image3 : currentRepair.image3,
        subtotal: subtotal.toFixed(2),
        iva: iva.toFixed(2),
        total: total.toFixed(2),
        includeIVA,
        status: formData.status || currentRepair.status || "Espera de confirmación",
        paymentStatus: validPaymentStatusesRepair.includes(formData.paymentStatus)
          ? formData.paymentStatus
          : (currentRepair as any).paymentStatus || "No Pagada",
        reviewReason: formData.reviewReason !== undefined ? formData.reviewReason : currentRepair.reviewReason,
        updatedAt: new Date(),
      };
      
      // Actualizar la reparación
      const repair = await storage.updateRepair(id, repairData);
      if (!repair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      
      // Eliminar todos los items anteriores
      const existingItems = await storage.getRepairItems(id);
      for (const item of existingItems) {
        await storage.deleteRepairItem(item.id);
      }
      
      // Crear los nuevos items
      console.log(`PATCH Repair ${id}: Creando ${items.length} items nuevos`);
      for (const item of items) {
        const quantity = typeof item.quantity === 'string' ? parseFloat(item.quantity) : item.quantity;
        const unitPrice = typeof item.unitPrice === 'string' ? parseFloat(item.unitPrice) : item.unitPrice;
        const itemSubtotal = ((quantity || 0) * (unitPrice || 0)).toFixed(2);
        
        console.log(`Item: ${item.concept}, qty=${quantity}, price=${unitPrice}, subtotal=${itemSubtotal}`);
        
        await storage.addRepairItem(id, {
          itemNumber: item.itemNumber,
          concept: item.concept,
          quantity: quantity.toString(),
          unit: item.unit,
          unitPrice: unitPrice.toString(),
          subtotal: itemSubtotal,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
      }
      
      // Recalcular y sincronizar totales desde los items guardados en la BD
      await storage.updateRepairTotals(id);
      
      // Obtener la reparación actualizada
      const updatedRepair = await storage.getRepairById(id);
      
      res.status(200).json(updatedRepair);
    } catch (error) {
      console.error(`Error al actualizar reparación con ID ${req.params.id}:`, error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // PATCH - Quick status update (fast endpoint)
  app.patch(`${apiPrefix}/repairs/:id/status`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const { status } = req.body;
      const validStatuses = ["Espera de confirmación", "Diagnóstico", "En Proceso", "Entregada", "Terminada", "No Entregada", "No autorizado"];
      
      if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ message: "Estado inválido" });
      }
      
      const repair = await storage.updateRepair(id, { 
        status, 
        updatedAt: new Date() 
      });
      
      if (!repair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      
      res.status(200).json(repair);
    } catch (error) {
      console.error(`Error al actualizar estado de reparación con ID ${req.params.id}:`, error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // PATCH - Actualizar solo las fechas de la reparación (rápido desde la tarjeta)
  app.patch(`${apiPrefix}/repairs/:id/dates`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const { receivedDate, deliveryDate } = req.body;
      const updates: any = { updatedAt: new Date() };

      const parseLocalDate = (value: string) => {
        // Si viene como "YYYY-MM-DD", anclamos al mediodía UTC para evitar
        // que la zona horaria CDMX (GMT-6) la mueva al día anterior.
        if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
          return new Date(`${value}T12:00:00.000Z`);
        }
        return new Date(value);
      };

      if (receivedDate !== undefined) {
        updates.receivedDate = receivedDate ? parseLocalDate(receivedDate) : null;
      }
      if (deliveryDate !== undefined) {
        updates.deliveryDate = deliveryDate ? parseLocalDate(deliveryDate) : null;
      }

      const repair = await storage.updateRepair(id, updates);
      if (!repair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      res.status(200).json(repair);
    } catch (error) {
      console.error(`Error al actualizar fechas de reparación con ID ${req.params.id}:`, error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  app.patch(`${apiPrefix}/repairs/:id/payment-status`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const { paymentStatus } = req.body;
      const validPaymentStatuses = ["Pagada", "No Pagada", "Cotización"];
      
      if (!paymentStatus || !validPaymentStatuses.includes(paymentStatus)) {
        return res.status(400).json({ message: "Estado de pago inválido" });
      }
      
      const repair = await storage.updateRepair(id, { 
        paymentStatus, 
        updatedAt: new Date() 
      });
      
      if (!repair) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      
      res.status(200).json(repair);
    } catch (error) {
      console.error(`Error al actualizar estado de pago de reparación con ID ${req.params.id}:`, error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // DELETE - Delete repair
  app.delete(`${apiPrefix}/repairs/:id`, requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      // Obtener la reparación antes de borrarla para conocer sus fotos en el almacenamiento
      const repair = await storage.getRepairById(id);
      
      const success = await storage.deleteRepair(id);
      if (!success) {
        return res.status(404).json({ message: "Reparación no encontrada" });
      }
      
      // Borrar del almacenamiento las fotos con URL (las Base64 antiguas no aplican)
      if (repair) {
        const bucketId = process.env.REPLIT_BUCKET_ID || '';
        const storageUrls = [repair.image1, repair.image2, repair.image3].filter((url): url is string =>
          !!url && (
            url.startsWith('/public/') ||
            url.startsWith('https://storage.googleapis.com/') ||
            (!!bucketId && url.includes(bucketId))
          )
        );
        for (const url of storageUrls) {
          // Aislar fallos por imagen: la reparación ya se borró de la BD,
          // así que un fallo de storage no debe convertir la respuesta en error
          try {
            const deleted = await deleteStoredImageByUrl(url);
            if (!deleted) {
              console.error(`No se pudo borrar la imagen del almacenamiento para la reparación ${id}:`, url.slice(0, 100));
            }
          } catch (err) {
            console.error(`Error borrando imagen del almacenamiento para la reparación ${id}:`, url.slice(0, 100), err);
          }
        }
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error(`Error al eliminar reparación con ID ${req.params.id}:`, error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // Routes for client reports
  app.get(`${apiPrefix}/reports/clients`, async (req, res) => {
    try {
      const clientReports = await storage.getClientReports();
      res.json(clientReports);
    } catch (error) {
      console.error('Error fetching client reports:', error);
      res.status(500).json({ message: 'Error obteniendo los reportes de clientes' });
    }
  });



  // Get Zoho authorization URL
  app.get(`${apiPrefix}/zoho-auth-url`, (req, res) => {
    const clientId = process.env.ZOHO_CLIENT_ID;
    if (!clientId) {
      return res.status(400).json({ error: 'ZOHO_CLIENT_ID no configurado' });
    }
    
    const redirectUri = 'https://renta-maquinaria-psfidalgomx.replit.app/api/zoho-callback';
    const scope = 'ZohoMail.messages.CREATE,ZohoMail.accounts.READ';
    
    const authUrl = `https://accounts.zoho.com/oauth/v2/auth?` +
      `scope=${encodeURIComponent(scope)}&` +
      `client_id=${clientId}&` +
      `response_type=code&` +
      `access_type=offline&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}`;
    
    res.json({
      authUrl: authUrl,
      clientId: clientId,
      redirectUri: redirectUri,
      instructions: [
        '1. Visita la URL de autorización',
        '2. Autoriza la aplicación en Zoho',
        '3. Copia el código de la URL de retorno',
        '4. Usa el código en el endpoint /api/zoho-token'
      ]
    });
  });

  // Zoho OAuth token exchange endpoint
  app.post(`${apiPrefix}/zoho-token`, async (req, res) => {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: 'Código de autorización requerido' });
    }

    try {
      const clientId = process.env.ZOHO_CLIENT_ID;
      const clientSecret = process.env.ZOHO_CLIENT_SECRET;
      
      if (!clientId || !clientSecret) {
        return res.status(400).json({ error: 'Credenciales de Zoho no configuradas' });
      }
      
      const redirectUri = 'https://renta-maquinaria-psfidalgomx.replit.app/api/zoho-callback';
      
      // Exchange code for tokens
      const tokenResponse = await fetch('https://accounts.zoho.com/oauth/v2/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: redirectUri,
          code: code,
        }),
      });

      const tokenData = await tokenResponse.json();
      
      if (tokenData.error) {
        return res.status(400).json({ error: tokenData.error });
      }

      res.json({
        success: true,
        refresh_token: tokenData.refresh_token,
        access_token: tokenData.access_token,
        expires_in: tokenData.expires_in,
        message: 'Configura ZOHO_REFRESH_TOKEN con el valor del refresh_token'
      });
    } catch (error) {
      console.error('Error exchanging code for tokens:', error);
      res.status(500).json({ error: 'Error obteniendo tokens de Zoho' });
    }
  });

  // Test route to verify it works
  app.get(`${apiPrefix}/test-zoho`, (req, res) => {
    const baseUrl = `${req.protocol}://${req.get('host')}`;
    res.send(`
      <html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
          <h2>Zoho OAuth Setup</h2>
          <p>Tu aplicación está corriendo en: <strong>${baseUrl}</strong></p>
          <p>Para configurar Zoho OAuth, visita:</p>
          <a href="${baseUrl}${apiPrefix}/auth/zoho" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Iniciar configuración Zoho OAuth
          </a>
        </body>
      </html>
    `);
  });

  // Zoho OAuth routes - temporary for setup
  app.get(`${apiPrefix}/auth/zoho`, (req, res) => {
    const clientId = process.env.ZOHO_CLIENT_ID;
    if (!clientId) {
      return res.status(400).json({ error: 'ZOHO_CLIENT_ID not configured. Please set up your Zoho credentials first.' });
    }
    
    const redirectUri = `${req.protocol}://${req.get('host')}/auth/zoho/callback`;
    const scope = 'ZohoMail.messages.CREATE,ZohoMail.accounts.READ';
    
    const authUrl = `https://accounts.zoho.com/oauth/v2/auth?` +
      `scope=${encodeURIComponent(scope)}&` +
      `client_id=${clientId}&` +
      `response_type=code&` +
      `access_type=offline&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}`;
    
    res.redirect(authUrl);
  });

  app.get(`${apiPrefix}/auth/zoho/callback`, async (req, res) => {
    const { code } = req.query;
    
    if (!code) {
      return res.status(400).json({ error: 'No authorization code received' });
    }

    try {
      const clientId = process.env.ZOHO_CLIENT_ID;
      const clientSecret = process.env.ZOHO_CLIENT_SECRET;
      
      if (!clientId || !clientSecret) {
        return res.status(400).json({ error: 'Zoho credentials not configured' });
      }
      
      const redirectUri = `${req.protocol}://${req.get('host')}${apiPrefix}/auth/zoho/callback`;
      
      // Exchange code for tokens
      const tokenResponse = await fetch('https://accounts.zoho.com/oauth/v2/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: redirectUri,
          code: code as string,
        }),
      });

      const tokenData = await tokenResponse.json();
      
      if (tokenData.error) {
        return res.status(400).json({ error: tokenData.error });
      }

      // Display the tokens for the user to copy
      res.send(`
        <html>
          <head><title>Zoho OAuth Success</title></head>
          <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h1>¡Zoho OAuth configurado exitosamente!</h1>
            <p>Copia estos valores y configúralos como secretos en tu proyecto:</p>
            <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
              <strong>ZOHO_REFRESH_TOKEN:</strong><br>
              <code style="word-break: break-all;">${tokenData.refresh_token}</code>
            </div>
            <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
              <strong>ZOHO_ACCESS_TOKEN (temporal):</strong><br>
              <code style="word-break: break-all;">${tokenData.access_token}</code>
            </div>
            <p><strong>Expira en:</strong> ${tokenData.expires_in} segundos</p>
            <p>El refresh_token es el que necesitas para configurar permanentemente.</p>
          </body>
        </html>
      `);
    } catch (error) {
      console.error('Error exchanging code for tokens:', error);
      res.status(500).json({ error: 'Error getting tokens from Zoho' });
    }
  });

  // ================ API de reportes ================

  // GET - Obtener el siguiente número de reporte
  app.get(`${apiPrefix}/reports/next-number`, async (req, res) => {
    try {
      const nextNumber = await storage.getNextReportNumber();
      return res.json({ nextNumber });
    } catch (error) {
      console.error("Error getting next report number:", error);
      return res.status(500).json({ message: "Error obteniendo el siguiente número de reporte" });
    }
  });

  // GET - Obtener todos los reportes para cálculos de totales (debe ir ANTES que la ruta con parámetro)
  app.get(`${apiPrefix}/reports/totals`, async (req, res) => {
    try {
      const allReports = await storage.getAllReportsForTotals();
      res.json(allReports);
    } catch (error) {
      console.error('Error fetching reports totals:', error);
      res.status(500).json({ message: 'Error obteniendo los totales de reportes' });
    }
  });

  // GET - Obtener todos los reportes con paginación
  app.get(`${apiPrefix}/reports`, async (req, res) => {
    try {
      const page = Number(req.query.page) || 1;
      const limit = Number(req.query.limit) || 100;
      
      const reports = await storage.getReports(page, limit);
      return res.json(reports);
    } catch (error) {
      console.error("Error getting reports:", error);
      return res.status(500).json({ message: "Error obteniendo los reportes" });
    }
  });

  // GET - Obtener un reporte por ID con items
  app.get(`${apiPrefix}/reports/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      const report = await storage.getReportById(id);
      if (!report) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }
      
      
      return res.json(report);
    } catch (error) {
      console.error("Error getting report:", error);
      return res.status(500).json({ message: "Error obteniendo el reporte" });
    }
  });

  // POST - Crear un nuevo reporte
  app.post(`${apiPrefix}/reports`, async (req, res) => {
    try {
      const reportData = req.body;
      
      console.log("API - Creando nuevo reporte:", reportData);
      
      // Validar que el cliente y proyecto existen
      const client = await storage.getClientById(reportData.clientId);
      if (!client) {
        return res.status(404).json({ message: "Cliente no encontrado" });
      }
      
      const project = await storage.getClientProjectById(reportData.projectId);
      if (!project) {
        return res.status(404).json({ message: "Proyecto no encontrado" });
      }
      
      // Validar items
      if (!reportData.items || reportData.items.length === 0) {
        return res.status(400).json({ message: "Debe incluir al menos un concepto en el reporte" });
      }
      
      // Calcular totales
      let subtotal = 0;
      reportData.items.forEach((item: any) => {
        const itemSubtotal = item.cantidad * item.precioUnitario;
        subtotal += itemSubtotal;
        item.subtotal = itemSubtotal;
      });
      
      const includeIva = reportData.includeIva ?? true;
      const iva = includeIva ? subtotal * 0.16 : 0;
      const total = subtotal + iva;
      
      // Sincronizar dias_uso desde los items para el Estado de Cuenta
      const diasUsoFromItems = reportData.items
        .map((item: any) => item.diasUso)
        .filter((dias: string) => dias && dias.trim() !== "")
        .filter((dias: string, index: number, array: string[]) => array.indexOf(dias) === index) // eliminar duplicados
        .join(", ");
      
      // Obtener el siguiente número de reporte
      const reportNumber = await storage.getNextReportNumber();
      
      // Crear reporte
      const newReport = await storage.createReport({
        reportNumber,
        folioReporte: reportData.folioReporte,
        clientId: reportData.clientId,
        clientName: reportData.clientName,
        projectId: reportData.projectId,
        diasUso: diasUsoFromItems || reportData.diasUso,
        nombreObra: reportData.nombreObra,
        fechaReporte: new Date(reportData.fechaReporte),
        periodoRentaInicio: reportData.periodoRentaInicio ? new Date(reportData.periodoRentaInicio) : null,
        periodoRentaFin: reportData.periodoRentaFin ? new Date(reportData.periodoRentaFin) : null,
        subtotal: subtotal.toString(),
        iva: iva.toString(),
        total: total.toString(),
        includeIva
      });
      
      // Crear items del reporte
      const reportItems = [];
      for (const item of reportData.items) {
        const reportItem = await storage.createReportItem({
          reportId: newReport.id,
          numero: item.numero,
          concepto: item.concepto,
          obra: item.obra,
          diasUso: item.diasUso,
          periodoRenta: reportData.periodoRentaInicio && reportData.periodoRentaFin 
            ? `${new Date(reportData.periodoRentaInicio).toLocaleDateString("es-MX")} - ${new Date(reportData.periodoRentaFin).toLocaleDateString("es-MX")}`
            : "",
          cantidad: item.cantidad.toString(),
          unidad: item.unidad,
          precioUnitario: item.precioUnitario.toString(),
          subtotal: item.subtotal.toString()
        });
        reportItems.push(reportItem);
      }
      
      console.log("API - Reporte creado exitosamente:", newReport.id);
      
      return res.status(201).json({
        ...newReport,
        items: reportItems
      });
    } catch (error) {
      console.error("Error creating report:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error creando el reporte" });
    }
  });

  // PUT - Actualizar un reporte
  app.put(`${apiPrefix}/reports/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      const reportData = req.body;
      
      // Crear objeto solo con campos válidos del schema
      const processedReportData: any = {};
      
      // Solo incluir campos que existen en el schema
      if (reportData.folioReporte !== undefined) processedReportData.folioReporte = reportData.folioReporte;
      if (reportData.clientName !== undefined) processedReportData.clientName = reportData.clientName;
      if (reportData.diasUso !== undefined) processedReportData.diasUso = reportData.diasUso;
      if (reportData.nombreObra !== undefined) processedReportData.nombreObra = reportData.nombreObra;
      if (reportData.subtotal !== undefined) processedReportData.subtotal = reportData.subtotal.toString();
      if (reportData.iva !== undefined) processedReportData.iva = reportData.iva.toString();
      if (reportData.total !== undefined) processedReportData.total = reportData.total.toString();
      if (reportData.includeIva !== undefined) processedReportData.includeIva = reportData.includeIva;
      if (reportData.paymentStatus !== undefined) processedReportData.paymentStatus = reportData.paymentStatus;
      
      // Procesar fechas correctamente
      if (reportData.fechaReporte) {
        const fechaDate = new Date(reportData.fechaReporte);
        if (!isNaN(fechaDate.getTime())) {
          processedReportData.fechaReporte = fechaDate;
        }
      }
      if (reportData.periodoRentaInicio) {
        const inicioDate = new Date(reportData.periodoRentaInicio);
        if (!isNaN(inicioDate.getTime())) {
          processedReportData.periodoRentaInicio = inicioDate;
        }
      }
      if (reportData.periodoRentaFin) {
        const finDate = new Date(reportData.periodoRentaFin);
        if (!isNaN(finDate.getTime())) {
          processedReportData.periodoRentaFin = finDate;
        }
      }
      
      // Recalcular totales si hay items (igual que en la creación)
      if (reportData.items && Array.isArray(reportData.items)) {
        let subtotal = 0;
        reportData.items.forEach((item: any) => {
          const itemSubtotal = item.cantidad * item.precioUnitario;
          subtotal += itemSubtotal;
        });
        
        const includeIva = reportData.includeIva ?? true;
        const iva = includeIva ? subtotal * 0.16 : 0;
        const total = subtotal + iva;
        
        // Actualizar los totales calculados
        processedReportData.subtotal = subtotal.toString();
        processedReportData.iva = iva.toString();
        processedReportData.total = total.toString();
      }
      
      // Actualizar reporte
      const updatedReport = await storage.updateReport(id, processedReportData);
      
      // Si hay items, actualizar también los items del reporte
      if (reportData.items && Array.isArray(reportData.items)) {
        // Primero eliminar items existentes
        await storage.deleteReportItems(id);
        
        // Luego agregar los nuevos items
        const reportItems = [];
        for (const item of reportData.items) {
          const reportItem = await storage.createReportItem({
            reportId: id,
            numero: item.numero,
            concepto: item.concepto,
            obra: item.obra,
            diasUso: item.diasUso,
            periodoRenta: processedReportData.periodoRentaInicio && processedReportData.periodoRentaFin 
              ? `${new Date(processedReportData.periodoRentaInicio).toLocaleDateString("es-MX")} - ${new Date(processedReportData.periodoRentaFin).toLocaleDateString("es-MX")}`
              : "",
            cantidad: item.cantidad.toString(),
            unidad: item.unidad,
            precioUnitario: item.precioUnitario.toString(),
            subtotal: item.subtotal.toString()
          });
          reportItems.push(reportItem);
        }
      }
      
      if (!updatedReport) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }
      
      // Obtener el reporte completo con items incluidos para devolver
      const completeReport = await storage.getReportById(id);
      
      return res.json(completeReport);
    } catch (error) {
      console.error("Error updating report:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error actualizando el reporte" });
    }
  });

  // POST - Duplicar un reporte
  app.post(`${apiPrefix}/reports/:id/duplicate`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      // Obtener el reporte original con todos sus items
      const originalReport = await storage.getReportById(id);
      if (!originalReport) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }

      console.log("API - Duplicando reporte:", originalReport.reportNumber);

      // Validar que el cliente y proyecto aún existen
      const client = await storage.getClientById(originalReport.clientId);
      if (!client) {
        return res.status(404).json({ message: "Cliente del reporte original no encontrado" });
      }
      
      const project = await storage.getClientProjectById(originalReport.projectId);
      if (!project) {
        return res.status(404).json({ message: "Proyecto del reporte original no encontrado" });
      }

      // Obtener el siguiente número de reporte
      const newReportNumber = await storage.getNextReportNumber();
      // Usar el folio original con " COPIA" al final para que el usuario pueda modificarlo
      const newFolioNumber = `${originalReport.folioReporte} COPIA`;
      
      // Crear el reporte duplicado con nueva fecha y número
      const duplicatedReport = await storage.createReport({
        reportNumber: newReportNumber,
        folioReporte: newFolioNumber,
        clientId: originalReport.clientId,
        clientName: originalReport.clientName,
        projectId: originalReport.projectId,
        diasUso: originalReport.diasUso,
        nombreObra: originalReport.nombreObra,
        fechaReporte: new Date(), // Nueva fecha actual
        periodoRentaInicio: originalReport.periodoRentaInicio,
        periodoRentaFin: originalReport.periodoRentaFin,
        subtotal: originalReport.subtotal,
        iva: originalReport.iva,
        total: originalReport.total,
        includeIva: originalReport.includeIva,
        paymentStatus: 'pendiente' // Nuevo reporte siempre pendiente
      });

      // Duplicar todos los items del reporte original
      const duplicatedItems = [];
      if (originalReport.items && originalReport.items.length > 0) {
        for (const originalItem of originalReport.items) {
          const duplicatedItem = await storage.createReportItem({
            reportId: duplicatedReport.id,
            numero: originalItem.numero,
            concepto: originalItem.concepto,
            obra: originalItem.obra,
            diasUso: originalItem.diasUso,
            periodoRenta: originalItem.periodoRenta,
            cantidad: originalItem.cantidad,
            unidad: originalItem.unidad,
            precioUnitario: originalItem.precioUnitario,
            subtotal: originalItem.subtotal
          });
          duplicatedItems.push(duplicatedItem);
        }
      }

      console.log("API - Reporte duplicado exitosamente:", duplicatedReport.reportNumber);

      return res.status(201).json({
        ...duplicatedReport,
        items: duplicatedItems
      });
    } catch (error) {
      console.error("Error duplicating report:", error);
      return res.status(500).json({ message: "Error duplicando el reporte" });
    }
  });

  // DELETE - Eliminar un reporte
  app.delete(`${apiPrefix}/reports/:id`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      const success = await storage.deleteReport(id);
      
      if (!success) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting report:", error);
      return res.status(500).json({ message: "Error eliminando el reporte" });
    }
  });

  // PATCH - Actualizar estado de pago de un reporte (con sincronización automática)
  app.patch(`${apiPrefix}/reports/:id/payment-status`, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      const { paymentStatus } = req.body;
      
      // Validar que el estado de pago es válido
      const validStatuses = ['pendiente', 'facturado', 'pagado', 'vencido'];
      if (!validStatuses.includes(paymentStatus)) {
        return res.status(400).json({ message: "Estado de pago inválido" });
      }

      // Obtener el reporte actual
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, id)
      });

      if (!report) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }

      // Si el usuario marca como "Pendiente", eliminar abonos automáticos del sistema
      if (paymentStatus === 'pendiente') {
        // Buscar todos los abonos automáticos (creados por el Sistema)
        const systemPayments = await db.query.reportPayments.findMany({
          where: and(
            eq(reportPayments.reportId, id),
            eq(reportPayments.createdBy, 'Sistema')
          )
        });
        
        // Eliminar abonos automáticos
        if (systemPayments.length > 0) {
          for (const payment of systemPayments) {
            await db.delete(reportPayments)
              .where(eq(reportPayments.id, payment.id));
          }
          
          const totalDeleted = systemPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
          console.log(`🗑️ ABONOS AUTOMÁTICOS ELIMINADOS: ${systemPayments.length} abono(s) por $${totalDeleted.toFixed(2)} del reporte ${id} (marcado como Pendiente)`);
        }
      }

      // Si el usuario marca como "Pagado", crear abono automático si falta
      if (paymentStatus === 'pagado') {
        // Obtener todos los abonos existentes
        const existingPayments = await db.query.reportPayments.findMany({
          where: eq(reportPayments.reportId, id)
        });
        
        const totalPaid = existingPayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
        const reportTotal = parseFloat(report.total) || 0;
        const remaining = reportTotal - totalPaid;
        
        // Si falta dinero por abonar, crear abono automático
        if (remaining > 0.01) { // Tolerancia de 1 centavo
          await db.insert(reportPayments)
            .values({
              reportId: id,
              amount: remaining.toString(),
              paymentDate: new Date(),
              paymentMethod: 'Sistema',
              reference: 'Abono automático al marcar como Pagado',
              notes: `Abono automático generado por el sistema para completar el 100% del pago`,
              createdBy: 'Sistema'
            });
          
          console.log(`💰 ABONO AUTOMÁTICO CREADO: $${remaining.toFixed(2)} para reporte ${id} (marcado como Pagado)`);
        }
      }

      // Primero actualizar el estado manualmente
      await db.update(reports)
        .set({ 
          paymentStatus,
          updatedAt: new Date()
        })
        .where(eq(reports.id, id));
      
      console.log(`✅ Estado manual actualizado: Reporte ${id} -> ${paymentStatus}`);
      
      // Luego recalcular estado basado en abonos (esto puede sobrescribir el estado si es necesario)
      await updatePaymentStatusBasedOnPayments(id);
      
      // Obtener el reporte actualizado después de todos los cambios
      const finalReport = await db.query.reports.findFirst({
        where: eq(reports.id, id)
      });
      
      return res.json(finalReport);
    } catch (error) {
      console.error("Error al actualizar estado de pago:", error);
      return res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // GET - Obtener todos los abonos de un reporte
  app.get(`${apiPrefix}/reports/:id/payments`, async (req, res) => {
    try {
      const reportId = Number(req.params.id);
      if (isNaN(reportId)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      // Verificar que el reporte existe
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, reportId)
      });
      
      if (!report) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }

      // Obtener todos los abonos del reporte ordenados por fecha de pago
      const payments = await db.query.reportPayments.findMany({
        where: eq(reportPayments.reportId, reportId),
        orderBy: desc(reportPayments.paymentDate)
      });

      // Calcular totales
      const totalPaid = payments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
      const remaining = parseFloat(report.total) - totalPaid;

      return res.json({
        payments,
        summary: {
          reportTotal: parseFloat(report.total),
          totalPaid,
          remaining: Math.max(0, remaining)
        }
      });
    } catch (error) {
      console.error("Error obteniendo abonos:", error);
      return res.status(500).json({ message: "Error obteniendo los abonos" });
    }
  });

  // POST - Agregar un nuevo abono a un reporte
  app.post(`${apiPrefix}/reports/:id/payments`, async (req, res) => {
    try {
      const reportId = Number(req.params.id);
      if (isNaN(reportId)) {
        return res.status(400).json({ message: "ID de reporte inválido" });
      }

      const paymentData = req.body;
      
      // Validar datos con Zod
      const validatedData = reportPaymentInsertSchema.parse({
        ...paymentData,
        reportId,
        amount: paymentData.amount != null ? String(paymentData.amount) : paymentData.amount,
        paymentDate: new Date(paymentData.paymentDate),
        createdBy: paymentData.createdBy || 'Sistema'
      });

      // Verificar que el reporte existe
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, reportId)
      });
      
      if (!report) {
        return res.status(404).json({ message: "Reporte no encontrado" });
      }

      // Verificar que el abono no excede lo pendiente
      const existingPayments = await db.query.reportPayments.findMany({
        where: eq(reportPayments.reportId, reportId)
      });
      
      const totalPaid = existingPayments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
      const remaining = parseFloat(report.total) - totalPaid;
      
      if (parseFloat(validatedData.amount) > remaining) {
        return res.status(400).json({ 
          message: `El abono excede el monto pendiente. Pendiente: $${remaining.toFixed(2)}` 
        });
      }

      // Crear el abono
      const newPayment = await db.insert(reportPayments)
        .values(validatedData)
        .returning();

      console.log(`API - Abono creado: $${validatedData.amount} para reporte ${reportId}`);
      
      // Recalcular estado de pago automáticamente
      await updatePaymentStatusBasedOnPayments(reportId);
      
      return res.status(201).json(newPayment[0]);
    } catch (error) {
      console.error("Error creando abono:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Error creando el abono" });
    }
  });

  // PATCH - Actualizar un abono existente
  app.patch(`${apiPrefix}/reports/:id/payments/:paymentId`, async (req, res) => {
    try {
      const reportId = Number(req.params.id);
      const paymentId = Number(req.params.paymentId);
      
      if (isNaN(reportId) || isNaN(paymentId)) {
        return res.status(400).json({ message: "IDs inválidos" });
      }

      // Validar datos de actualización con Zod schema
      const validatedData = reportPaymentUpdateSchema.parse(req.body);

      // Verificar que el abono existe
      const payment = await db.query.reportPayments.findFirst({
        where: eq(reportPayments.id, paymentId)
      });
      
      if (!payment) {
        return res.status(404).json({ message: "Abono no encontrado" });
      }
      
      // SEGURIDAD: Verificar que el abono pertenece al reporte especificado
      if (payment.reportId !== reportId) {
        return res.status(403).json({ message: "El abono no pertenece a este reporte" });
      }

      // Actualizar el abono con datos validados
      const updatedPayment = await db.update(reportPayments)
        .set({
          ...validatedData,
          updatedAt: new Date()
        })
        .where(eq(reportPayments.id, paymentId))
        .returning();

      console.log(`API - Abono actualizado: ${paymentId} del reporte ${reportId}`);
      
      return res.json(updatedPayment[0]);
    } catch (error) {
      console.error("Error actualizando abono:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Datos de actualización inválidos",
          errors: error.errors 
        });
      }
      return res.status(500).json({ message: "Error actualizando el abono" });
    }
  });

  // DELETE - Eliminar un abono
  app.delete(`${apiPrefix}/reports/:id/payments/:paymentId`, async (req, res) => {
    try {
      const reportId = Number(req.params.id);
      const paymentId = Number(req.params.paymentId);
      
      if (isNaN(reportId) || isNaN(paymentId)) {
        return res.status(400).json({ message: "IDs inválidos" });
      }

      // Verificar que el abono existe y pertenece al reporte
      const payment = await db.query.reportPayments.findFirst({
        where: eq(reportPayments.id, paymentId)
      });
      
      if (!payment) {
        return res.status(404).json({ message: "Abono no encontrado" });
      }
      
      if (payment.reportId !== reportId) {
        return res.status(400).json({ message: "El abono no pertenece a este reporte" });
      }

      // Eliminar el abono
      await db.delete(reportPayments)
        .where(eq(reportPayments.id, paymentId));

      console.log(`API - Abono eliminado: ${paymentId} del reporte ${reportId}`);
      
      // Recalcular estado de pago automáticamente
      await updatePaymentStatusBasedOnPayments(reportId);
      
      return res.json({ success: true, message: "Abono eliminado correctamente" });
    } catch (error) {
      console.error("Error eliminando abono:", error);
      return res.status(500).json({ message: "Error eliminando el abono" });
    }
  });

  // Función auxiliar para recalcular estado de pago automáticamente
  async function updatePaymentStatusBasedOnPayments(reportId: number) {
    try {
      // Obtener el reporte
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, reportId)
      });
      
      if (!report) return;
      
      // Obtener todos los pagos del reporte
      const payments = await db.query.reportPayments.findMany({
        where: eq(reportPayments.reportId, reportId)
      });
      
      const totalPaid = payments.reduce((sum, payment) => sum + parseFloat(payment.amount), 0);
      const reportTotal = parseFloat(report.total) || 0;
      
      // Determinar el nuevo estado basado en el porcentaje abonado
      let newStatus: 'pendiente' | 'facturado' | 'pagado';
      
      if (reportTotal <= 0) {
        // Si el total es 0 o negativo, mantener pendiente
        newStatus = 'pendiente';
      } else {
        // Redondear a centavos para evitar problemas de precisión
        const totalPaidCents = Math.round(totalPaid * 100);
        const reportTotalCents = Math.round(reportTotal * 100);
        const paidPercentage = (totalPaidCents / reportTotalCents) * 100;
        
        if (totalPaidCents === 0) {
          newStatus = 'pendiente';  // 0% pagado - Rojo
        } else if (totalPaidCents >= reportTotalCents) {
          newStatus = 'pagado';  // 100% o más pagado - Verde
        } else {
          newStatus = 'facturado';  // 1-99% pagado - Amarillo
        }
      }
      
      const paidPercentage = reportTotal > 0 ? (totalPaid / reportTotal) * 100 : 0;
      
      // Actualizar el estado solo si es diferente al actual
      if (report.paymentStatus !== newStatus) {
        await db.update(reports)
          .set({ 
            paymentStatus: newStatus,
            updatedAt: new Date()
          })
          .where(eq(reports.id, reportId));
        
        console.log(`⚙️ ESTADO AUTO-ACTUALIZADO: Reporte ${reportId} -> ${newStatus} (${paidPercentage.toFixed(1)}% pagado - $${totalPaid.toFixed(2)} de $${reportTotal.toFixed(2)})`);
      }
    } catch (error) {
      console.error('Error actualizando estado de pago automáticamente:', error);
    }
  }

  // POST - Upload repair image to Object Storage
  app.post(`${apiPrefix}/upload-image`, (req, res, next) => {
    upload.single('file')(req, res, (err) => {
      if (err) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(413).json({ message: "El archivo es demasiado grande. El límite es 50MB." });
        }
        return res.status(400).json({ message: "Error procesando el archivo: " + err.message });
      }
      next();
    });
  }, async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No se recibió ningún archivo" });
      }

      const rawRepairNumber = req.body.repairNumber || 'unknown';
      const repairNumber = String(rawRepairNumber).replace(/[^a-zA-Z0-9_-]/g, '-') || 'unknown';
      const imageIndex = String(req.body.imageIndex || '1').replace(/[^0-9]/g, '') || '1';
      const timestamp = Date.now();
      const ext = req.file.mimetype.includes('png') ? 'png' : 'jpg';
      const objectPath = `public/repairs/repair-${repairNumber}-image-${imageIndex}-${timestamp}.${ext}`;

      const client = new ObjectStorageClient({ bucketId: process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID });
      // Content-Type se determina por la extensión al servir la imagen
      const result = await client.uploadFromBytes(objectPath, req.file.buffer);

      if (!result.ok) {
        console.error("Error subiendo a Object Storage:", result.error);
        return res.status(500).json({ message: "Error al subir la imagen al almacenamiento" });
      }

      // Return a relative URL served by this server (GET /public/repairs/:filename)
      return res.json({ url: `/${objectPath}` });
    } catch (error) {
      console.error("Error uploading image:", error);
      return res.status(500).json({ message: "Error al subir la imagen" });
    }
  });

  // GET - Serve repair images from Object Storage
  app.get('/public/repairs/:filename', async (req, res) => {
    try {
      const filename = req.params.filename;
      // Prevent path traversal
      if (filename.includes('..') || filename.includes('/')) {
        return res.status(400).json({ message: "Nombre de archivo inválido" });
      }
      const objectPath = `public/repairs/${filename}`;
      const client = new ObjectStorageClient({ bucketId: process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID });
      const result = await client.downloadAsBytes(objectPath);
      if (!result.ok) {
        return res.status(404).json({ message: "Imagen no encontrada" });
      }
      const bytes = Array.isArray(result.value) ? result.value[0] : result.value;
      res.set('Content-Type', filename.endsWith('.png') ? 'image/png' : 'image/jpeg');
      res.set('Cache-Control', 'public, max-age=31536000, immutable');
      return res.send(bytes);
    } catch (error) {
      console.error("Error sirviendo imagen:", error);
      return res.status(500).json({ message: "Error al obtener la imagen" });
    }
  });

  // POST - Delete repair image from Object Storage (requiere sesión activa)
  app.post(`${apiPrefix}/delete-image`, requireAuth, async (req, res) => {
    try {
      const { url } = req.body;

      if (!url || typeof url !== 'string') {
        return res.status(400).json({ message: "URL de imagen requerida" });
      }

      // Solo se permiten fotos de reparación (prefijo public/repairs/)
      const objectPath = resolveRepairImagePath(url);
      if (!objectPath) {
        return res.status(400).json({ message: "Formato de URL de imagen no reconocido" });
      }

      // Si otra reparación aún referencia la foto (p. ej., duplicados), no borrarla
      if (await isRepairImageReferenced(url)) {
        return res.json({ success: true, skipped: true, message: "La imagen sigue en uso por otra reparación" });
      }

      const client = new ObjectStorageClient({ bucketId: process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID });
      const result = await client.delete(objectPath);
      if (!result.ok) {
        console.error("Error eliminando de Object Storage:", result.error);
        return res.status(500).json({ message: "Error al eliminar la imagen del almacenamiento" });
      }

      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting image:", error);
      return res.status(500).json({ message: "Error al eliminar la imagen" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
