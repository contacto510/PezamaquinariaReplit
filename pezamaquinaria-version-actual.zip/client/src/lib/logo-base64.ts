// Logo de Péza Maquinaria en formato JPG base64 - ORIGINAL del usuario
export const PEZA_LOGO_BASE64 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QLgRXhpZgAATU0AKgAAAAgABAE7AAIAAAAHAAABSodpAAQAAAABAAABUpydAAEAAAAOAAACyuocAAcAAAEMAAAAPgAAAAAc6gAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWC1UZXJtAAAABZADAAIAAAAUAAACoJAEAAIAAAAUAAACtJKRAAIAAAADODQAAJKSAAIAAAADODQAAOocAAcAAAEMAAABlAAAAAAc6gAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMjAyNDowODowNiAxMTowODo1OAAyMDI0OjA4OjA2IDExOjA4OjU4AAAAWAAtAFQAZQByAG0AAAD/4QQZaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIvPjxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSJ1dWlkOmZhZjViZGQ1LWJhM2QtMTFkYS1hZDMxLWQzM2Q3NTE4MmYxYiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIj48eG1wOkNyZWF0ZURhdGU+MjAyNC0wOC0wNlQxMTowODo1OC44Mzk8L3htcDpDcmVhdGVEYXRlPjwvcmRmOkRlc2NyaXB0aW9uPjxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSJ1dWlkOmZhZjViZGQ1LWJhM2QtMTFkYS1hZDMxLWQzM2Q3NTE4MmYxYiIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj48ZGM6Y3JlYXRvcj48cmRmOlNlcSB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPjxyZGY6bGk+WC1UZXJtPC9yZGY6bGk+PC9yZGY6U2VxPg0KCQkJPC9kYzpjcmVhdG9yPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSd3Jz8+/9sAQwAHBQUGBQQHBgUGCAcHCAoRCwoJCQoVDxAMERgVGhkYFRgXGx4nIRsdJR0XGCIuIiUoKSssKxogLzMvKjInKisq/9sAQwEHCAgKCQoUCwsUKhwYHCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq/8AAEQgALADPAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A9ou/+P6f/ro386hqa7/4/p/+ujfzqGvyDEfxp+r/ADPbj8KCiuf8b+J18I+FrjVBGksqlUhic4DsT049s15P/wAL91j/AKA1h/32/wDjXZhcrxWLh7SlHTbcidWEHZnvFFeD/wDC/dY/6A1h/wB9v/jXdfDn4l/8JrNc2l7aR2d5AvmDy2JV06d+QRWmIyfGYem6tSOi80KNaEnZHfUV4prPx1vrPW7y207TLOa1hmZIpJHfc4Bxk4NUv+F/az/0BtP/AO+3/wAa1jkOOlFNR380T9Yp9z3iivGNB+MXiXxFrVvpum6FYvNM2M75MIvdjz0Fbfjz4uJ4W1JNL0u3gv72MZumdiI4zj7oxyT/AC+tZSyfFqqqPL7z13W3n2K9tC1z0yivB/8Ahf2sf9Aaw/77f/GtLQfi/wCKPEmrxadpWgWMs0h5O+Tai92Y54ArWeRY2EXKSSS80SsRB7Hs1FRw+aIE+0FDLtG8xghc98Z7V5V4w+NY0bXZNO0GygvltyUmnlc7S/cLjrjpmvPwuDrYubhRV2jSU4wV2es0V5r8OvinP4x1yfTNQsYLWQQmWFoWY7sH5gc+xz+Br0qoxWFq4Wp7OqrMcZqaujzr46/8kqvf+u0X/oVfKVfVvx1/5JVe/wDXaL/0KvlKvueG/wDc3/if5I8/FfGFKqs7BUBZmOAB3NJXQ+Dre3fU5bq6jnkW0j8xVgXJBJChsYOQM5x7V9BUnyQcjmSuyeDSLHTNH1Ce8SO+1G2ETNbMzCOFWbadxUglsleOgzTbW30vV9EuJriC30qVJUjimiLlCTnhgzHA9xTl06O0/tGFvEOlN9sj8p/O89WGJFcHHlcHKj8zUQ06EaUbEeIdHCGbzS26fJOMY/1Vcd27vmd7rvtp0KMO8s5rC8ktrpdskZwR1z6EeoI5qCur8SWNuvh2ylR5priyKWj3RRljnDB3G0MobCfdyeo9sVylddGp7SNyWrMK+kf2SP8Ambv+3L/2vXzdX0j+yR/zN3/bl/7XrUR7Pd/8f0//AF0b+dQ1Nd/8f0//AF0b+dVppUhheWVgqIpZmPYAZJr8gr61per/ADPbj8KPD/jxr3nanY6JC/y26+fMAf4jwP0rk/CviPRfC+hXE93pdrq+pXcwVIbhQUgiXucjqST+ArJ1y/uPF3jK5uogWlv7nbCvoCdqD8sV9J6Z4H0Cw0q1tH0mymaCJUaSSBWZyBgkkjqTX22Iq0cswVLD1U3fdJ283+JwxUqs3JHz54n8bWniLTEtLfw7pmmMsoczWyAOcA/LnA45rZ8IWN94U8J6x4ru0e2E1sbSyVxhpGfjcB6AV7vH4X0GGQSRaNYI6nIZbZAR+leSfHjXd97YaFA3ywr58yj1PCj8s1hhcwhjJRwdCnaL1d3fRav79hypuC55M808NyafF4gt7nWyDZW7GaVCMmXbyEx7nArutO+IP9tasljpHgTRp5pnxHGIQTj1PHHua4/wx4o/4Rlrlho+nak1wFGb2MvsAz90Z755+grqrD4wahaXIOm+GNEhmk+QeRA4Zs9uDk17GNo1Kk21S5rLT3rL7kYwaS3Pc9E0i3060ST+zrCzvHQecbOIKufQHGSKxPF0vhHwvpkupaxpWnvI5Plx/Z0Mk7+g4/M1Dd+OJ/DPguLVPGUEFvqc4Ji0+2JyfRTknn1PQV89+JfEuo+KtYk1DVZdzniOMfdiXsqj0r5fLcsr4qs6lSVoJ6tPfyT7eZ11KsYRstzRhstS+Ivi4ppdhb228/cgjCRW8fqcD/65r6G8HeDdO8G6SLWxXfO4BuLlh80rf0HoK8K8L/FC88JaWLLSdF03k5kmfzDJKfUnP6V6jd/EPU9D+H66z4ltLa11O9z9gsYgwOMcM+ScevsMdzXdnFPGVHGhBWheyV9X6/1p1M6Lgvee5X+LfxB/sGxbRNImxqVymJZFPMEZ/wDZj+nWvM/BfgCfxFouqavchktLW3kMP/TWULn8hXI317c6lfzXl9K008zl5HY8kmvUPCvxK8Qaj9k8MaB4e0wRsnkqoMmEXGCzHP4k16H1Orl+DUMNbm3lJu3r/wAAz51UneRy/wAKr37F8S9KYnAldoT/AMCUj+eK+oB0r5G0uSTR/GNq7/K9peqGx2Kvg/yr64DBhkdDyK8biWH76nUXVfl/w5vhXo0ed/HX/klV7/12i/8AQq+Uq+rfjr/ySq9/67Rf+hV8ryW08KxNLC6CZd0ZZSN4zjI9ea9fhv8A3N/4n+SOfFfGRVZ0+6azvopVkkjUOPM8typK55HHtTXsrqOaSKS3lWSJd0oUIKj1I7dantNF1S+t/PstPuZ4skb44mYZHXkCvpN9zlOxu9StbrVGkvLbTZU1C1Z7O6mgdcOGwA/zf7LLn1INQRyRLJZ2SWGjPqE0pZzHGzrFGBnnDYJ4JwKyrLWrtJrKw1LTYruIbUdXtg00sPZAT0wM4IwffipptUk0VLf+yNLMcAXCXN7ZgStL13hgTggEYGcd8Vl7Gn2Hdmf4p1c6vrUssdxJLAdrYYsF37RvIUk7QWycVjVNJBcGScyRSb4iTNlTlDnHPpzVmHQtWuLUXMGm3UkBUsJFhYqQO+cVokoqyEUK+kf2SP8Ambv+3L/2vXzmbW4Dshhk3KgkK7TkKRnP0wRX0X+yP/zN3/bl/wC16YHtF3/x/T/9dG/nVd0SWNkkVXRgQysMgj0rp3020kkZ3iyzHJO49fzpv9lWX/PH/wAfb/GvhKnDmLlUclKOr7v/ACPRWKglazONi0PSYJVkh0yzjkQ5VkgUFT6g4q/XR/2VZf8APH/x9v8AGj+yrL/nj/4+3+NTLhzGy+KcX83/AJB9aproc5VK40fTLuYzXWn2s8p6vJCrMfxIrsP7Ksv+eP8A4+3+NH9lWX/PH/x9v8aUeHMbF3U4r5v/ACD61TfRnF/8I9ov/QJsf/AdP8KfFomlW8yywabZxyIcq6QKCp9QcV2P9lWX/PH/AMfb/Gj+yrL/AJ4/+Pt/jV/6v49/8vF97/yD6zT7HJXWl2F86ve2VvcOowGliViB+NQf8I9ov/QJsf8AwHT/AArtP7Ksv+eP/j7f40f2VZf88f8Ax9v8aS4ex6VlUX3v/IPrNPscYugaOjBk0qyVlOQRbpwfyqa602xvmVr2zt7llGFMsQbA9s11v9lWX/PH/wAfb/Gj+yrL/nj/AOPt/jR/q9jr39pH73/kH1qn2OL/AOEe0X/oE2P/AIDp/hU9rpen2Mheysra3cjBaKJVJH1Arrf7Ksv+eP8A4+3+NH9lWX/PH/x9v8aHw9j2rOovvf8AkH1mn2ONfQtIkkMkml2bOx3FjApJPrnFXwABgcCuj/sqy/54/wDj7f40f2VZf88f/H2/xpPhzGy3nH73/kH1qn2PF/jr/wAkrvP+u0X/AKFXhkfjHSm02xt7+2kum0yzjaxyBhLhQQyH1jOQ31T3NfZWu+C9A8TaU+m63YfabSRgzR+dImSORyrA/rXKf8M+/DH/AKFn/wAn7n/45X0+U4KpgsO6VRpu99P6RyVqiqSuj5sh8e6TaapcajNbz6hPqCpHeBiELRiMBlyc8M2SfoKuaJ4h8LxW1jZHXtVsI7GWQQeWjBWBmMis+G5yp2njtX0P/wAM+/DH/oWf/J+5/wDjlH/DPvwx/wChZ/8AJ+5/+OV6xifNkmveGZvFFn4gl1G6jns1H+irbbg5QEAB89Dx2pt/450u/wDsen3SzS6WygXAKfNC4VAsie42n6ivpX/hn34Y/wDQs/8Ak/c//HKP+Gffhj/0LP8A5P3P/wAcoA+bIvGnh+0u9UU2txd2+s3E8l43CEIzkRr3yACX/wB4j0qxpfj/AEbS7O2giF49xYwKLWdpXWIsueGjBwQeOfzr6L/4Z9+GP/Qs/wDk/c//AByj/hn34Y/9Cz/5P3P/AMcoA+abLxvo2mX0l79lmvJLqCG2uE4TESQorKCc/eYH8AK9X/ZZFoNS8bf2aztal7MxFxhtv7/ANd//AMM+/DH/AKFn/wAn7n/45XSeEfh94Y8CfbP+EV0z7B9t2faP9Ill37N2377HGN7dMdaAP//Z";

// Función principal para agregar el logo JPG original sin pixelación
export function addPezaLogo(doc: any, x: number, y: number, width: number, height: number) {
  try {
    // Calculamos las dimensiones exactas del logo original (207x44 píxeles)
    const originalWidth = 207;
    const originalHeight = 44;
    const aspectRatio = originalWidth / originalHeight; // 4.7045...
    
    // Calculamos el tamaño óptimo manteniendo la proporción exacta
    let logoWidth, logoHeight;
    
    if (width / height > aspectRatio) {
      // Si el área disponible es más ancha que la proporción del logo
      logoHeight = height;
      logoWidth = height * aspectRatio;
    } else {
      // Si el área disponible es más alta que la proporción del logo
      logoWidth = width;
      logoHeight = width / aspectRatio;
    }
    
    // Posición centrada dentro del área asignada
    const logoX = x + (width - logoWidth) / 2;
    const logoY = y + (height - logoHeight) / 2;
    
    // Agregar la imagen JPG con dimensiones exactas para evitar pixelación
    doc.addImage(
      PEZA_LOGO_BASE64, 
      'JPEG', 
      logoX, 
      logoY, 
      logoWidth, 
      logoHeight,
      undefined, // alias
      'MEDIUM' // compression - usa calidad media para mejor resultado
    );
    
  } catch (error) {
    console.warn('Error agregando logo JPG al PDF:', error);
    // Si falla, usar una versión simplificada pero clara
    addFallbackLogo(doc, x, y, width, height);
  }
}

// Función de respaldo mejorada
function addFallbackLogo(doc: any, x: number, y: number, width: number, height: number) {
  const aspectRatio = 4.7;
  let logoWidth, logoHeight;
  
  if (width / height > aspectRatio) {
    logoHeight = height;
    logoWidth = height * aspectRatio;
  } else {
    logoWidth = width;
    logoHeight = width / aspectRatio;
  }
  
  const logoX = x + (width - logoWidth) / 2;
  const logoY = y + (height - logoHeight) / 2;
  
  // Fondo amarillo "PÉZA"
  doc.setFillColor(255, 215, 0);
  doc.rect(logoX, logoY, logoWidth * 0.63, logoHeight, "F");
  
  // Fondo negro "MAQUINARIA"
  doc.setFillColor(35, 35, 35);
  doc.rect(logoX + logoWidth * 0.63, logoY, logoWidth * 0.37, logoHeight, "F");
  
  // Texto "PÉZA"
  doc.setFont("helvetica", "bold");
  doc.setFontSize(Math.max(4, logoHeight * 0.4));
  doc.setTextColor(35, 35, 35);
  doc.text("PÉZA", logoX + logoWidth * 0.02, logoY + logoHeight * 0.65);
  
  // Texto "MAQUINARIA"
  doc.setFont("helvetica", "normal");
  doc.setFontSize(Math.max(2, logoHeight * 0.15));
  doc.setTextColor(255, 255, 255);
  doc.text("MAQUINARIA", logoX + logoWidth * 0.65, logoY + logoHeight * 0.35);
  
  // Ícono de engranaje
  const gearX = logoX + logoWidth * 0.85;
  const gearY = logoY + logoHeight * 0.7;
  const gearRadius = logoHeight * 0.1;
  
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.3);
  doc.circle(gearX, gearY, gearRadius);
  
  // Dientes del engranaje
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI * 2) / 6;
    const x1 = gearX + Math.cos(angle) * gearRadius * 0.8;
    const y1 = gearY + Math.sin(angle) * gearRadius * 0.8;
    const x2 = gearX + Math.cos(angle) * gearRadius * 1.2;
    const y2 = gearY + Math.sin(angle) * gearRadius * 1.2;
    doc.line(x1, y1, x2, y2);
  }
  
  // Restaurar configuración
  doc.setTextColor(0, 0, 0);
  doc.setDrawColor(0, 0, 0);
}